import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const pkgRoot = path.resolve(__dirname, '..');
const sourceFile = path.join(pkgRoot, 'src', 'features', 'music', 'MusicMiniPlayer.tsx');
const targetFile = path.resolve(process.cwd(), 'src', 'features', 'music', 'MusicMiniPlayer.tsx');

if (!fs.existsSync(sourceFile)) {
  console.error('ERROR: Replacement MusicMiniPlayer.tsx is missing from the package.');
  process.exit(1);
}
if (!fs.existsSync(targetFile)) {
  console.error(`ERROR: Target file not found: ${targetFile}`);
  process.exit(1);
}

const backupPath = `${targetFile}.bak-r8-4-${new Date().toISOString().replace(/[:.]/g, '-')}`;
fs.copyFileSync(targetFile, backupPath);
fs.copyFileSync(sourceFile, targetFile);
const sha = crypto.createHash('sha256').update(fs.readFileSync(targetFile)).digest('hex');

console.log('MVP Trainer V5 R8.4 applied successfully.');
console.log(`Updated: ${path.relative(process.cwd(), targetFile)}`);
console.log(`Backup:  ${path.relative(process.cwd(), backupPath)}`);
console.log(`SHA-256: ${sha}`);
console.log('');
console.log('Next: run npm run build, then test desktop + mobile before committing.');
