import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const VERSION = "v5-music-intelligence-suite-r2";
const MARKER = "MVP_TRAINER_V5_MUSIC_INTELLIGENCE_SUITE";
const F = {
  intelligence:path.join(ROOT,"src","lib","musicIntelligence.ts"),
  player:path.join(ROOT,"src","lib","musicPlayer.ts"),
  page:path.join(ROOT,"src","features","music","MusicPage.tsx"),
  workout:path.join(ROOT,"src","features","workout","WorkoutPlayerPage.tsx"),
};
function stop(m){console.error(`\nMVP Trainer V5 stopped: ${m}\nNo source files were written.`);process.exit(1);}
for(const k of ["player","page","workout"])if(!fs.existsSync(F[k]))stop(`${k} source missing. Run from repo root.`);
const O={player:fs.readFileSync(F.player,"utf8"),page:fs.readFileSync(F.page,"utf8"),workout:fs.readFileSync(F.workout,"utf8")};
if(O.player.includes(MARKER)||O.page.includes(MARKER)||O.workout.includes(MARKER)){console.log("V5 Music Intelligence Suite already installed.");process.exit(0);}
let player=O.player,page=O.page,workout=O.workout;
const intelligence="import type { MusicTrack } from \"./musicStorage\";\nimport { createMusicPlaylist, listMusicPlaylists, replaceMusicPlaylistTracks } from \"./playlistStorage\";\n\nexport const LIKED_SONGS_PLAYLIST_NAME = \"Liked Songs\";\nexport type MusicRadioMode = \"more_like_this\" | \"harder\" | \"heavier\" | \"faster\" | \"melodic\";\nexport type WorkoutMusicStage = \"off\" | \"warmup\" | \"working\" | \"heavy\" | \"finisher\";\nexport type SongDna = { energy:number; heavy:number; melodic:number; dark:number; drive:number; workoutFit:number };\nexport type PrSoundtrackRecord = {\n  id:string; trackId:string; title:string; artist:string; exerciseName:string;\n  setNumber:number; records:string[]; createdAt:string;\n};\n\nconst K = {\n  radio:\"mvp_music_neural_radio_v1\",\n  recent:\"mvp_music_neural_recent_v1\",\n  stage:\"mvp_music_workout_stage_v1\",\n  automix:\"mvp_music_automix_v1\",\n  prs:\"mvp_music_pr_soundtrack_v1\",\n};\n\nfunction clamp(n:number){ return Math.max(0,Math.min(100,Math.round(n))); }\nfunction read<T>(key:string,fallback:T):T {\n  if(typeof window===\"undefined\") return fallback;\n  try{ const raw=localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback; }catch{return fallback;}\n}\nfunction write(key:string,value:unknown){ if(typeof window!==\"undefined\"){ try{localStorage.setItem(key,JSON.stringify(value));}catch{} } }\nfunction words(track:MusicTrack){ return `${track.artist||\"\"} ${track.album||\"\"} ${track.title||\"\"} ${track.genre||\"\"}`.toLowerCase(); }\nfunction has(value:string, list:string[]){ return list.some(x=>value.includes(x)); }\nfunction artist(track:MusicTrack){ return (track.artist||\"Unknown Artist\").trim().toLowerCase(); }\n\nexport function getSongDna(track:MusicTrack):SongDna{\n  const text=words(track);\n  const energy=track.energy_level===\"high\"?88:track.energy_level===\"medium\"?62:34;\n  let heavy=34+(energy-50)*.38;\n  if(has(text,[\"metal\",\"hard rock\",\"metalcore\",\"hardcore\",\"industrial\",\"nu metal\",\"post-hardcore\"])) heavy+=31;\n  if(has(text,[\"acoustic\",\"soft rock\",\"pop\"])) heavy-=14;\n  let melodic=50;\n  if(has(text,[\"melodic\",\"alternative\",\"post-grunge\",\"rock\",\"anthem\",\"acoustic\"])) melodic+=22;\n  let dark=34;\n  if(has(text,[\"dark\",\"doom\",\"goth\",\"industrial\",\"death\",\"grave\",\"pain\",\"dead\"])) dark+=28;\n  let drive=energy*.77+12;\n  if(has(text,[\"punk\",\"thrash\",\"speed\",\"hardcore\",\"metalcore\"])) drive+=15;\n  if(track.favorite) drive+=5;\n  if(track.play_less) drive-=25;\n  const completion=track.play_count?Math.min(1,track.completed_play_count/Math.max(1,track.play_count)):.45;\n  const skip=track.play_count?Math.min(1,track.skip_count/Math.max(1,track.play_count)):0;\n  const workoutFit=energy*.54+clamp(heavy)*.18+clamp(drive)*.17+completion*18-skip*24+(track.favorite?10:0)-(track.play_less?40:0);\n  return {energy:clamp(energy),heavy:clamp(heavy),melodic:clamp(melodic),dark:clamp(dark),drive:clamp(drive),workoutFit:clamp(workoutFit)};\n}\n\nexport function radioModeLabel(mode:MusicRadioMode){\n  return mode===\"harder\"?\"Harder\":mode===\"heavier\"?\"Heavier\":mode===\"faster\"?\"Faster\":mode===\"melodic\"?\"More Melodic\":\"More Like This\";\n}\nexport function adaptiveRadioQueueName(seed:MusicTrack,mode:MusicRadioMode){ return `MVP Neural \u2022 ${radioModeLabel(mode)} \u2022 ${seed.title}`; }\nexport function isAdaptiveRadioName(name:string|null|undefined){ return !!name&&(name.startsWith(\"MVP Neural \u2022\")||name.startsWith(\"Like Radio \u2022\")); }\n\nexport function setWorkoutMusicContext(activeIndex:number,total:number,done=0){\n  let stage:WorkoutMusicStage=\"off\";\n  if(total>0){\n    const p=Math.max(activeIndex,done)/Math.max(1,total-1);\n    stage=p<=.12?\"warmup\":p>=.82?\"finisher\":p>=.48?\"heavy\":\"working\";\n  }\n  write(K.stage,stage); return stage;\n}\nexport function getWorkoutMusicStage():WorkoutMusicStage{ return read<WorkoutMusicStage>(K.stage,\"off\"); }\n\nfunction recentIds(){ return read<string[]>(K.recent,[]).slice(0,24); }\nfunction remember(id:string){ write(K.recent,[id,...recentIds().filter(x=>x!==id)].slice(0,24)); }\nfunction stageBias(d:SongDna,s:WorkoutMusicStage){\n  return s===\"warmup\"?22-Math.abs(d.energy-64)*.35:\n    s===\"working\"?d.workoutFit*.23+d.drive*.12:\n    s===\"heavy\"?d.heavy*.2+d.energy*.18+d.drive*.16:\n    s===\"finisher\"?d.workoutFit*.28+d.energy*.2+d.drive*.2:d.workoutFit*.08;\n}\nfunction distance(a:SongDna,b:SongDna,mode:MusicRadioMode){\n  const w=mode===\"heavier\"?[.8,1.9,.5,.7,.9]:mode===\"faster\"?[1.1,.6,.5,.4,2]:\n    mode===\"melodic\"?[.7,.5,2,.5,.7]:mode===\"harder\"?[1.6,1.4,.4,.5,1.5]:[1,1,1,.7,1];\n  const vals=[Math.abs(a.energy-b.energy),Math.abs(a.heavy-b.heavy),Math.abs(a.melodic-b.melodic),Math.abs(a.dark-b.dark),Math.abs(a.drive-b.drive)];\n  return vals.reduce((s,v,i)=>s+v*w[i],0)/w.reduce((s,v)=>s+v,0);\n}\nfunction score(seed:MusicTrack,current:MusicTrack,c:MusicTrack,mode:MusicRadioMode,recent:Set<string>,recentArtists:Set<string>){\n  if(c.id===current.id||c.id===seed.id||c.play_less) return -99999;\n  const sd=getSongDna(seed), cd=getSongDna(c);\n  let value=100-distance(sd,cd,mode);\n  if(artist(seed)===artist(c)) value+=20;\n  if(artist(current)===artist(c)) value-=34;\n  if(recent.has(c.id)) value-=130;\n  if(recentArtists.has(artist(c))) value-=24;\n  if(mode===\"harder\") value+=Math.max(0,cd.energy-sd.energy)*.7+Math.max(0,cd.heavy-sd.heavy)*.5;\n  if(mode===\"heavier\") value+=Math.max(0,cd.heavy-sd.heavy)*1.05;\n  if(mode===\"faster\") value+=Math.max(0,cd.drive-sd.drive)*1.05;\n  if(mode===\"melodic\") value+=Math.max(0,cd.melodic-sd.melodic)*1.05;\n  value+=stageBias(cd,getWorkoutMusicStage())+(c.favorite?10:0)+Math.min(12,c.completed_play_count*.8)-Math.min(26,c.skip_count*3.2);\n  if(c.last_played_at){\n    const h=(Date.now()-new Date(c.last_played_at).getTime())/3600000;\n    if(h<6)value-=45; else if(h<24)value-=22; else if(h<72)value-=9; else if(h>336)value+=8;\n  } else value+=12;\n  return value+Math.random()*4;\n}\n\nexport function startRadioSession(seed:MusicTrack,library:MusicTrack[],mode:MusicRadioMode=\"more_like_this\"){\n  write(K.radio,{seedTrackId:seed.id,mode,startedAt:new Date().toISOString()}); remember(seed.id);\n  const recent=new Set(recentIds()), recentArtists=new Set<string>();\n  return [seed,...library.filter(t=>t.id!==seed.id&&!t.play_less)\n    .map(t=>({t,s:score(seed,seed,t,mode,recent,recentArtists)})).sort((a,b)=>b.s-a.s).slice(0,50).map(x=>x.t)];\n}\nexport function chooseAdaptiveNextTrack(current:MusicTrack,library:MusicTrack[]){\n  const radio=read<{seedTrackId:string;mode:MusicRadioMode}|null>(K.radio,null); if(!radio)return null;\n  const seed=library.find(t=>t.id===radio.seedTrackId)||current, ids=recentIds(), recent=new Set(ids);\n  const recentArtists=new Set(ids.map(id=>library.find(t=>t.id===id)).filter((x):x is MusicTrack=>!!x).map(artist));\n  const next=library.filter(t=>t.id!==current.id&&!t.play_less).map(t=>({t,s:score(seed,current,t,radio.mode,recent,recentArtists)})).sort((a,b)=>b.s-a.s)[0]?.t||null;\n  if(next) remember(next.id); return next;\n}\n\nexport function isAutoMixEnabled(){ const v=read<boolean|null>(K.automix,null); return v===null?true:v; }\nexport function setAutoMixEnabled(v:boolean){ write(K.automix,!!v); }\n\nexport async function syncLikedSongsPlaylist(library:MusicTrack[]){\n  const playlists=await listMusicPlaylists();\n  let p=playlists.find(x=>x.name.trim().toLowerCase()===LIKED_SONGS_PLAYLIST_NAME.toLowerCase())||null;\n  if(!p)p=await createMusicPlaylist(LIKED_SONGS_PLAYLIST_NAME);\n  const ids=library.filter(t=>t.favorite).sort((a,b)=>new Date(b.updated_at||b.created_at).getTime()-new Date(a.updated_at||a.created_at).getTime()).map(t=>t.id);\n  await replaceMusicPlaylistTracks(p.id,ids);\n  if(typeof window!==\"undefined\")window.dispatchEvent(new Event(\"mvp:music-playlists-changed\"));\n  return p;\n}\n\nfunction stale(t:MusicTrack){ return t.last_played_at?(Date.now()-new Date(t.last_played_at).getTime())/3600000:Infinity; }\nexport function buildDiscoveryRadar(library:MusicTrack[]){\n  const a=library.filter(t=>!t.play_less);\n  return [\n    {id:\"forgotten\",title:\"Forgotten Favorites\",subtitle:\"Liked songs you have not heard lately\",tracks:[...a].filter(t=>t.favorite&&stale(t)>336).sort((x,y)=>stale(y)-stale(x)).slice(0,16)},\n    {id:\"deep\",title:\"Deep Cuts\",subtitle:\"Low-play tracks with strong workout potential\",tracks:[...a].filter(t=>t.play_count<=4&&t.skip_count<=1).sort((x,y)=>getSongDna(y).workoutFit-getSongDna(x).workoutFit).slice(0,16)},\n    {id:\"rare\",title:\"Rarely Played\",subtitle:\"Hidden corners of your library\",tracks:[...a].sort((x,y)=>x.play_count-y.play_count).slice(0,16)},\n    {id:\"energy\",title:\"High-Energy Rediscovery\",subtitle:\"Hard-driving tracks that have cooled off\",tracks:[...a].filter(t=>t.energy_level===\"high\"&&stale(t)>168).sort((x,y)=>getSongDna(y).workoutFit-getSongDna(x).workoutFit).slice(0,16)},\n  ];\n}\nexport function buildTasteMap(library:MusicTrack[]){\n  const a=library.filter(t=>!t.play_less);\n  const defs=[\n    [\"heavy\",\"HEAVY\",\"Weight, impact, aggression\",(d:SongDna)=>d.heavy],\n    [\"drive\",\"HIGH DRIVE\",\"Forward motion and workout pace\",(d:SongDna)=>d.drive],\n    [\"melodic\",\"MELODIC\",\"Hooks and melodic pull\",(d:SongDna)=>d.melodic],\n    [\"dark\",\"DARK\",\"Darker tonal character\",(d:SongDna)=>d.dark],\n    [\"workout\",\"WORKOUT CORE\",\"Highest overall training fit\",(d:SongDna)=>d.workoutFit],\n  ] as const;\n  return defs.map(([id,label,subtitle,pick])=>{\n    const tracks=[...a].sort((x,y)=>pick(getSongDna(y))-pick(getSongDna(x))).slice(0,18);\n    const score=tracks.length?Math.round(tracks.reduce((s,t)=>s+pick(getSongDna(t)),0)/tracks.length):0;\n    return {id,label,subtitle,score,tracks};\n  });\n}\nexport function recordPrSoundtrack(track:MusicTrack,d:{exerciseName:string;setNumber:number;records:string[]}){\n  const old=read<PrSoundtrackRecord[]>(K.prs,[]);\n  const rec={id:`${Date.now()}:${track.id}`,trackId:track.id,title:track.title,artist:track.artist||\"Unknown Artist\",exerciseName:d.exerciseName,setNumber:d.setNumber,records:d.records,createdAt:new Date().toISOString()};\n  write(K.prs,[rec,...old].slice(0,100)); return rec;\n}\nexport function listPrSoundtracks(){ return read<PrSoundtrackRecord[]>(K.prs,[]); }\n";

// PLAYER IMPORT - R2 tolerant module matcher.
// Do not depend on the exact names, order, spacing, or line wrapping inside
// the existing playlistStorage import.
const intelligenceImport = `import {
  adaptiveRadioQueueName,
  chooseAdaptiveNextTrack,
  isAdaptiveRadioName,
  isAutoMixEnabled,
  startRadioSession,
  syncLikedSongsPlaylist,
  type MusicRadioMode,
} from "./musicIntelligence";`;

if (!player.includes('from "./musicIntelligence"')) {
  const playlistImportRx =
    /import\s*\{[\s\S]*?\}\s*from\s*["']\.\/playlistStorage["']\s*;/m;
  const match = player.match(playlistImportRx);
  if (!match || match.index == null) {
    stop("musicPlayer playlistStorage import module was not found.");
  }
  const insertAt = match.index + match[0].length;
  player =
    player.slice(0, insertAt) +
    `\n${intelligenceImport}` +
    player.slice(insertAt);
}

// ADAPTIVE NEXT / AUTOMIX
const oldNext=`export async function nextMusicTrack(fromEnded = false) {
  if (!state.libraryLoaded) await loadMusicLibrary();
  if (!fromEnded && shouldRecordSkip() && state.currentTrack) {
    void recordMusicTrackSkipped(state.currentTrack.id).catch(() => undefined);
  }
  const index = state.shuffle ? nextShuffleIndex() : nextSequentialIndex(1);
  if (index < 0) {
    if (fromEnded) stopMusic();
    return;
  }
  const track = state.tracks[index];
  if (track) await playMusicTrack(track.id, 0);
}`;
if(!player.includes(oldNext))stop("musicPlayer nextMusicTrack anchor not found.");
player=player.replace(oldNext,`/* ${MARKER}: ADAPTIVE NEXT */
async function playMvpAutoMixTransition(track: MusicTrack, fromEnded: boolean) {
  if (fromEnded || !isAutoMixEnabled() || !musicGain || !audioContext) {
    await playMusicTrack(track.id,0); return;
  }
  const original=Math.max(.0001,musicGain.gain.value||1);
  try { await fadeOutputTo(Math.min(original,.055),115); await playMusicTrack(track.id,0); }
  finally { await fadeOutputTo(original,235); }
}
export async function nextMusicTrack(fromEnded = false) {
  if (!state.libraryLoaded) await loadMusicLibrary();
  if (!fromEnded && shouldRecordSkip() && state.currentTrack) void recordMusicTrackSkipped(state.currentTrack.id).catch(()=>undefined);
  if(state.currentTrack && isAdaptiveRadioName(state.activePlaylistName)){
    const adaptive=chooseAdaptiveNextTrack(state.currentTrack,state.libraryTracks);
    if(adaptive){ await playMvpAutoMixTransition(adaptive,fromEnded); return; }
  }
  const index=state.shuffle?nextShuffleIndex():nextSequentialIndex(1);
  if(index<0){ if(fromEnded)stopMusic(); return; }
  const track=state.tracks[index]; if(track)await playMvpAutoMixTransition(track,fromEnded);
}`);

// LIKE / RADIO
const oldPref=`export async function setPlayerMusicPreference(
  trackId: string,
  preference: "neutral" | "like" | "play_less",
) {
  const updated = await setMusicTrackPreference(trackId, preference);
  const patchTrack = (track: MusicTrack) => (track.id === trackId ? updated : track);
  emit({
    libraryTracks: state.libraryTracks.map(patchTrack),
    tracks: state.tracks.map(patchTrack),
    currentTrack: state.currentTrack?.id === trackId ? updated : state.currentTrack,
  });
  return updated;
}`;
if(!player.includes(oldPref))stop("musicPlayer preference anchor not found.");
player=player.replace(oldPref,`/* ${MARKER}: LIKED SONGS + LIKE RADIO */
export async function setPlayerMusicPreference(trackId:string,preference:"neutral"|"like"|"play_less"){
  const wasCurrent=state.currentTrack?.id===trackId;
  const updated=await setMusicTrackPreference(trackId,preference);
  const patch=(t:MusicTrack)=>t.id===trackId?updated:t;
  const library=state.libraryTracks.map(patch), queue=state.tracks.map(patch);
  emit({libraryTracks:library,tracks:queue,currentTrack:wasCurrent?updated:state.currentTrack});
  void syncLikedSongsPlaylist(library).catch(e=>console.warn("Liked Songs sync failed.",e));
  if(preference==="like"&&wasCurrent){
    const radio=startRadioSession(updated,library,"more_like_this");
    activateMusicAdHocQueue(\`Like Radio • \${updated.title}\`,radio);
  }
  return updated;
}
export function startMvpNeuralRadio(seedTrackId:string,mode:MusicRadioMode="more_like_this"){
  const seed=state.libraryTracks.find(t=>t.id===seedTrackId);
  if(!seed)throw new Error("Song not found in your music library.");
  const queue=startRadioSession(seed,state.libraryTracks,mode);
  activateMusicAdHocQueue(adaptiveRadioQueueName(seed,mode),queue);
  return queue;
}
export function getMusicPlayerSnapshot(){ return state; }`);

// PAGE IMPORT - R2 tolerant module matcher.
if (!page.includes('from "../../lib/musicIntelligence"')) {
  const musicPlayerImportRx =
    /import\s*\{[\s\S]*?\}\s*from\s*["']\.\.\/\.\.\/lib\/musicPlayer["']\s*;/m;
  const match = page.match(musicPlayerImportRx);
  if (!match || match.index == null) {
    stop("MusicPage musicPlayer import module was not found.");
  }

  let patchedImport = match[0];
  if (!/\bstartMvpNeuralRadio\b/.test(patchedImport)) {
    patchedImport = patchedImport.replace(
      /\}\s*from\s*(["']\.\.\/\.\.\/lib\/musicPlayer["'])/,
      `  startMvpNeuralRadio,\n} from $1`
    );
  }

  const intelligencePageImport = `import {
  buildDiscoveryRadar, buildTasteMap, getSongDna, getWorkoutMusicStage,
  isAutoMixEnabled, listPrSoundtracks, radioModeLabel, setAutoMixEnabled,
  type MusicRadioMode,
} from "../../lib/musicIntelligence";`;

  page =
    page.slice(0, match.index) +
    patchedImport +
    `\n${intelligencePageImport}` +
    page.slice(match.index + match[0].length);
}

const tabType=`type MusicTab = "songs" | "artists" | "albums" | "playlists" | "smart" | "discover";`;
if(!page.includes(tabType))stop("MusicPage tab type not found.");
page=page.replace(tabType,`type MusicTab = "songs" | "artists" | "albums" | "playlists" | "smart" | "neural" | "discover";`);

const detail=`  const detailTrack = useMemo(() => tracks.find((track) => track.id === detailTrackId) || null, [tracks, detailTrackId]);`;
if(!page.includes(detail))stop("MusicPage detailTrack anchor not found.");
page=page.replace(detail,`${detail}
  /* ${MARKER}: INTELLIGENCE STATE */
  const [autoMixUi,setAutoMixUi]=useState(()=>isAutoMixEnabled());
  const discoveryRadar=useMemo(()=>buildDiscoveryRadar(tracks),[tracks]);
  const tasteMap=useMemo(()=>buildTasteMap(tracks),[tracks]);
  const prSoundtracks=useMemo(()=>listPrSoundtracks(),[tracks,player.currentTrack?.id]);
  const currentDna=useMemo(()=>player.currentTrack?getSongDna(player.currentTrack):null,[player.currentTrack?.id,player.currentTrack?.updated_at,player.currentTrack?.favorite,player.currentTrack?.play_less]);
  const likedTracks=useMemo(()=>tracks.filter(t=>t.favorite).sort((a,b)=>new Date(b.updated_at||b.created_at).getTime()-new Date(a.updated_at||a.created_at).getTime()),[tracks]);
  const workoutMusicStage=getWorkoutMusicStage();`);

const pref=`  async function changePreference(track: MusicTrack, preference: "like" | "play_less" | "neutral") {
    try {
      const updated = await setPlayerMusicPreference(track.id, preference);
      replaceTrackLocally(updated);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Could not update preference."); }
  }`;
if(!page.includes(pref))stop("MusicPage changePreference anchor not found.");
page=page.replace(pref,`${pref}
  function startNeuralMode(seed:MusicTrack|null,mode:MusicRadioMode){
    if(!seed){setError("Play or select a song before starting Neural Radio.");return;}
    try{
      const q=startMvpNeuralRadio(seed.id,mode);
      setMessage(\`MVP Neural • \${radioModeLabel(mode)} • \${q.length} library matches ready.\`);
      if(player.currentTrack?.id!==seed.id)void playMusicTrack(seed.id,0);
    }catch(c){setError(c instanceof Error?c.message:"Could not start Neural Radio.");}
  }
  function toggleAutoMix(){const next=!autoMixUi;setAutoMixUi(next);setAutoMixEnabled(next);setMessage(next?"AutoMix Flow enabled.":"AutoMix Flow disabled.");}`);

// TAB NAV
const oldTabs=`{([ ["songs","SONGS"], ["artists","ARTISTS"], ["albums","ALBUMS"], ["playlists","PLAYLISTS"], ["smart","SMART MIX"], ["discover","DISCOVER"] ] as Array<[MusicTab,string]>).map(([value,label]) => <button type="button" key={value} className={tab === value ? "is-active" : ""} onClick={() => { setTab(value); if (value === "discover") setDiscoveryView("archive"); }}>{label}</button>)}`;
if(!page.includes(oldTabs))stop("MusicPage tabs anchor not found.");
page=page.replace(oldTabs,`{([ ["songs","SONGS"], ["artists","ARTISTS"], ["albums","ALBUMS"], ["playlists","PLAYLISTS"], ["smart","SMART MIX"], ["neural","NEURAL"], ["discover","DISCOVER"] ] as Array<[MusicTab,string]>).map(([value,label]) => <button type="button" key={value} className={tab === value ? "is-active" : ""} onClick={() => { setTab(value); if (value === "discover") setDiscoveryView("archive"); }}>{label}</button>)}`);

// NEURAL UI
const discover=`        {tab === "discover" ? <section className="tr10-discover">`;
if(!page.includes(discover))stop("MusicPage discover section anchor not found.");
const ui=`        {tab === "neural" ? <section className="tr10-neural">
          <header className="tr10-neuralHero"><div><span>MVP MUSIC INTELLIGENCE</span><h2>Neural Radio</h2><p>Your uploaded library, continuously reshaped around your taste and workout stage.</p></div><div className="tr10-neuralStatus"><small>WORKOUT STAGE</small><strong>{workoutMusicStage.toUpperCase()}</strong><button className={autoMixUi?"is-on":""} onClick={toggleAutoMix}>AUTOMIX {autoMixUi?"ON":"OFF"}</button></div></header>
          <div className="tr10-neuralModes">{(["more_like_this","harder","heavier","faster","melodic"] as MusicRadioMode[]).map(mode=><button key={mode} disabled={!player.currentTrack} onClick={()=>startNeuralMode(player.currentTrack,mode)}><small>MVP NEURAL</small><strong>{radioModeLabel(mode).toUpperCase()}</strong></button>)}</div>
          <section className="tr10-intelBlock"><header><div><span>PERMANENT COLLECTION</span><h3>Liked Songs</h3><p>Every Like is synchronized here. Your other playlists are never edited.</p></div><b>{likedTracks.length}</b></header><div className="tr10-intelActions"><button disabled={!likedTracks.length} onClick={()=>void playMusicAdHocQueue("Liked Songs",likedTracks)}>▶ PLAY LIKED</button><button disabled={!likedTracks.length} onClick={()=>likedTracks[0]&&startNeuralMode(likedTracks[0],"more_like_this")}>∞ LIKED RADIO</button></div></section>
          <section className="tr10-intelBlock"><header><div><span>LIVE ANALYSIS</span><h3>Song DNA</h3><p>{player.currentTrack?\`\${player.currentTrack.title} • \${artistLabel(player.currentTrack)}\`:"Play a song to expose its intelligence profile."}</p></div></header>{currentDna?<div className="tr10-dnaGrid">{([["ENERGY",currentDna.energy],["HEAVY",currentDna.heavy],["MELODIC",currentDna.melodic],["DARK",currentDna.dark],["DRIVE",currentDna.drive],["WORKOUT FIT",currentDna.workoutFit]] as Array<[string,number]>).map(([label,value])=><div key={label}><span>{label}</span><strong>{String(value).padStart(2,"0")}</strong><i><b style={{width:\`\${value}%\`}} /></i></div>)}</div>:<div className="tr10-empty">NO ACTIVE SONG</div>}</section>
          <section className="tr10-intelBlock"><header><div><span>DISCOVERY RADAR</span><h3>Bring your library back to life</h3><p>Forgotten favorites, deep cuts, rarely played and high-energy rediscovery.</p></div></header><div className="tr10-radarGrid">{discoveryRadar.map(lane=><article key={lane.id}><small>{lane.tracks.length} TRACKS</small><h4>{lane.title}</h4><p>{lane.subtitle}</p><button disabled={!lane.tracks.length} onClick={()=>void playMusicAdHocQueue(\`Radar • \${lane.title}\`,lane.tracks)}>▶ PLAY</button></article>)}</div></section>
          <section className="tr10-intelBlock"><header><div><span>SONIC TERRITORY</span><h3>Taste Map</h3><p>Explore your library by musical character.</p></div></header><div className="tr10-tasteMap">{tasteMap.map(c=><button key={c.id} disabled={!c.tracks.length} onClick={()=>void playMusicAdHocQueue(\`Taste Map • \${c.label}\`,c.tracks)}><span>{c.label}</span><strong>{c.score}</strong><small>{c.subtitle}</small></button>)}</div></section>
          <section className="tr10-intelBlock"><header><div><span>PERFORMANCE MEMORY</span><h3>PR Soundtrack</h3><p>Songs playing when you hit personal records.</p></div><b>{prSoundtracks.length}</b></header>{prSoundtracks.length?<div className="tr10-prMusic">{prSoundtracks.slice(0,12).map(r=><article key={r.id}><strong>{r.title}</strong><span>{r.artist}</span><small>{r.exerciseName} • SET {r.setNumber} • {r.records.join(" + ")}</small><button onClick={()=>void playMusicTrack(r.trackId,0)}>▶</button></article>)}</div>:<div className="tr10-empty">PR songs will appear automatically when a PR is detected while music is playing.</div>}</section>
        </section> : null}

`;
page=page.replace(discover,ui+discover);

// INSPECTOR RADIO
const cmd=`<button onClick={() => addMusicToQueue(detailTrack.id)}>ADD TO QUEUE</button><button className={detailTrack.favorite ? "is-liked" : ""}`;
if(!page.includes(cmd))stop("MusicPage inspector anchor not found.");
page=page.replace(cmd,`<button onClick={() => addMusicToQueue(detailTrack.id)}>ADD TO QUEUE</button><button onClick={() => startNeuralMode(detailTrack,"more_like_this")}>∞ NEURAL RADIO</button><button className={detailTrack.favorite ? "is-liked" : ""}`);

// CSS
const close="      `}</style>";
if(!page.includes(close))stop("MusicPage CSS close anchor not found.");
const css=`
        /* ${MARKER}: UI */
        .tr10-neural{padding:11px;display:grid;gap:10px;background:radial-gradient(circle at 15% 0%,rgba(28,116,145,.12),transparent 34%),#03090d}.tr10-neuralHero{padding:17px;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;align-items:center;border:1px solid rgba(84,196,231,.22);border-radius:13px;background:linear-gradient(135deg,#081b24,#051016 58%,#071820)}.tr10-neuralHero span,.tr10-intelBlock>header span{color:#5dd8fa;font-size:6.5px;font-weight:1000;letter-spacing:.15em}.tr10-neuralHero h2{margin:4px 0;font-size:26px}.tr10-neuralHero p,.tr10-intelBlock>header p{margin:0;color:#88a3ad;font-size:8px}.tr10-neuralStatus{min-width:148px;padding:10px;border:1px solid rgba(105,184,210,.14);border-radius:10px;background:#061117;display:grid;gap:5px}.tr10-neuralStatus small{font-size:6px;color:#718993}.tr10-neuralStatus button{height:30px;border:1px solid rgba(116,156,170,.18);border-radius:7px;background:#071219;color:#a7bac1;font-size:7px;font-weight:1000}.tr10-neuralStatus button.is-on{border-color:rgba(61,210,245,.46);color:#baf1ff;background:#0a2b36}.tr10-neuralModes{display:grid;grid-template-columns:repeat(5,1fr);gap:7px}.tr10-neuralModes button{min-height:62px;padding:9px;border:1px solid rgba(80,179,214,.16);border-radius:10px;background:#07161d;color:#fff;text-align:left}.tr10-neuralModes small{display:block;color:#5b8594;font-size:5.5px}.tr10-neuralModes strong{display:block;margin-top:6px;font-size:8px}.tr10-intelBlock{border:1px solid rgba(94,165,190,.12);border-radius:12px;background:#050e13;overflow:hidden}.tr10-intelBlock>header{padding:12px 13px;display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid rgba(91,160,185,.09)}.tr10-intelBlock>header h3{margin:3px 0;font-size:15px}.tr10-intelBlock>header>b{font-size:25px;color:#67daf9}.tr10-intelActions{padding:10px;display:flex;gap:7px}.tr10-intelActions button,.tr10-radarGrid button{height:34px;padding:0 11px;border:1px solid rgba(61,204,244,.28);border-radius:8px;background:#08242e;color:#eafaff;font-size:7px;font-weight:1000}.tr10-dnaGrid{padding:10px;display:grid;grid-template-columns:repeat(6,1fr);gap:6px}.tr10-dnaGrid>div{padding:9px;border:1px solid rgba(102,163,184,.1);border-radius:9px;background:#071218}.tr10-dnaGrid span{display:block;color:#79939d;font-size:5.5px}.tr10-dnaGrid strong{display:block;margin:4px 0 6px;font-size:18px}.tr10-dnaGrid i{height:3px;display:block;background:#02070a}.tr10-dnaGrid i b{height:100%;display:block;background:linear-gradient(90deg,#2584a3,#61daf8)}.tr10-radarGrid{padding:10px;display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.tr10-radarGrid article{padding:10px;border:1px solid rgba(92,160,184,.1);border-radius:9px;background:#071219}.tr10-radarGrid h4{margin:5px 0}.tr10-radarGrid p{min-height:26px;color:#78919b;font-size:7px}.tr10-tasteMap{padding:14px;display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.tr10-tasteMap button{min-height:110px;padding:12px;border:1px solid rgba(85,177,209,.15);border-radius:50%;background:radial-gradient(circle,rgba(52,178,218,.16),#061219 68%);color:#fff}.tr10-tasteMap span,.tr10-tasteMap strong,.tr10-tasteMap small{display:block}.tr10-tasteMap strong{font-size:20px;margin:5px}.tr10-tasteMap small{font-size:5.5px;color:#8ba4ad}.tr10-prMusic{padding:9px;display:grid;gap:5px}.tr10-prMusic article{display:grid;grid-template-columns:1fr auto;padding:8px;border:1px solid rgba(101,166,188,.09);border-radius:8px;background:#071218}.tr10-prMusic span,.tr10-prMusic small{grid-column:1;color:#8da4ad;font-size:7px}.tr10-prMusic button{grid-column:2;grid-row:1/4;width:34px;height:34px;border-radius:50%;background:#082630;color:#fff;border:1px solid rgba(66,205,245,.27)}@media(max-width:760px){.tr10-neural{padding:7px}.tr10-neuralHero{grid-template-columns:1fr;padding:12px}.tr10-neuralModes{grid-template-columns:repeat(2,1fr)}.tr10-neuralModes button:first-child{grid-column:1/-1}.tr10-dnaGrid{grid-template-columns:repeat(3,1fr)}.tr10-radarGrid{grid-template-columns:1fr 1fr}.tr10-tasteMap{grid-template-columns:repeat(2,1fr)}.tr10-tabs{grid-template-columns:repeat(4,minmax(92px,1fr))!important;overflow-x:auto!important}}
`;
page=page.replace(close,css+"\n"+close);

// WORKOUT imports - R2 tolerant insertion.
if (!workout.includes('from "../../lib/musicIntelligence"')) {
  const assetImportIndex = workout.search(/^import\s+.+from\s+["']\.\.\/\.\.\/assets\//m);
  if (assetImportIndex < 0) stop("WorkoutPlayer asset-import insertion point was not found.");
  const additions =
`import { getMusicPlayerSnapshot } from "../../lib/musicPlayer";
import { recordPrSoundtrack, setWorkoutMusicContext } from "../../lib/musicIntelligence";

`;
  workout =
    workout.slice(0, assetImportIndex) +
    additions +
    workout.slice(assetImportIndex);
}

const stage=`  const doneCount = useMemo(() => items.filter((x) => !!x.completed_at).length, [items]);
  const current = items[activeIdx];`;
if(!workout.includes(stage))stop("WorkoutPlayer stage anchor not found.");
workout=workout.replace(stage,`${stage}
  /* ${MARKER}: WORKOUT MUSIC STAGE */
  useEffect(()=>{ setWorkoutMusicContext(activeIdx,items.length,doneCount); },[activeIdx,items.length,doneCount]);`);

const pr=`        records: prDetails,
      });
    } else if (hasNextSet) {`;
if(!workout.includes(pr))stop("WorkoutPlayer PR anchor not found.");
workout=workout.replace(pr,`        records: prDetails,
      });
      /* ${MARKER}: PR SOUNDTRACK */
      const prTrack=getMusicPlayerSnapshot().currentTrack;
      if(prTrack)recordPrSoundtrack(prTrack,{exerciseName:item?.name??"Exercise",setNumber:Number(row.set_index),records:prDetails.map(record=>record.label)});
    } else if (hasNextSet) {`);

const checks=[
 [player.includes("startMvpNeuralRadio"),"Neural player"],
 [player.includes("syncLikedSongsPlaylist"),"Liked Songs"],
 [player.includes("chooseAdaptiveNextTrack"),"adaptive next"],
 [page.includes('"neural","NEURAL"'),"Neural tab"],
 [page.includes("Song DNA"),"Song DNA"],
 [page.includes("Discovery Radar"),"Radar"],
 [page.includes("Taste Map"),"Taste Map"],
 [page.includes("PR Soundtrack"),"PR UI"],
 [workout.includes(`${MARKER}: WORKOUT MUSIC STAGE`),"workout stage"],
 [workout.includes(`${MARKER}: PR SOUNDTRACK`),"PR hook"],
];
for(const [ok,label] of checks)if(!ok)stop(`validation failed: ${label}`);

for(const [key,file] of Object.entries(F)){
 if(key==="intelligence"){if(fs.existsSync(file))fs.copyFileSync(file,`${file}.pre-${VERSION}.bak`);}
 else fs.copyFileSync(file,`${file}.pre-${VERSION}.bak`);
}
fs.writeFileSync(F.intelligence,intelligence,"utf8");
fs.writeFileSync(F.player,player,"utf8");
fs.writeFileSync(F.page,page,"utf8");
fs.writeFileSync(F.workout,workout,"utf8");

console.log(`
MVP Trainer V5 R2 Music Intelligence Suite applied successfully.
(${VERSION})

INSTALLED:
  ✓ Liked Songs + Like Radio
  ✓ MVP Neural Radio
  ✓ Workout-aware queueing
  ✓ Harder / Heavier / Faster / More Melodic / More Like This
  ✓ Song DNA
  ✓ Discovery Radar
  ✓ Anti-repetition intelligence
  ✓ AutoMix Flow
  ✓ PR Soundtrack Memory
  ✓ Taste Map
  ✓ No voice commands

NEXT: npm run build
`);
