import { useSyncExternalStore } from "react";
import {
  createMvpStudioNode,
  getMvpStudioRuntimeInfo,
  getMvpStudioTelemetry,
  resetMvpStudioLoudness,
  setMvpStudioState,
} from "./audio/mvpStudioEngine";
import {
  clearMusicUrlCache,
  getMusicArtworkSignedUrl,
  getMusicTrackSignedUrl,
  listMusicTracks,
  recordMusicTrackCompleted,
  recordMusicTrackPlayed,
  recordMusicTrackSkipped,
  setMusicTrackPreference,
  type MusicTrack,
} from "./musicStorage";
import {
  getMusicPlaylist,
  listMusicPlaylistTrackLinks,
  type MusicPlaylist,
} from "./playlistStorage";
import {
  adaptiveRadioQueueName,
  chooseAdaptiveNextTrack,
  isAdaptiveRadioName,
  isAutoMixEnabled,
  startRadioSession,
  syncLikedSongsPlaylist,
  type MusicRadioMode,
} from "./musicIntelligence";

export type MusicRepeatMode = "off" | "one" | "all";
export type MusicCustomPresetSlot = "custom_1" | "custom_2" | "custom_3";
export type MusicEqPreset =
  | "flat"
  | "power"
  | "rock"
  | "hard_rock"
  | "metal"
  | "alternative"
  | "pop"
  | "hip_hop"
  | "edm"
  | "bass_boost"
  | "deep_bass"
  | "punch"
  | "vocal"
  | "acoustic"
  | "warm"
  | "bright"
  | "late_night"
  | "headphones"
  | MusicCustomPresetSlot
  | "custom";
export type MusicDuckingStrength = "off" | "light" | "standard" | "strong";
export type MusicDspStatus = "active" | "bypassed" | "recovering" | "unavailable";
export type MusicDspEngineMode = "studio_wasm" | "advanced_worklet" | "native_fallback" | "unavailable";
export type MusicImmersionStatus = "active" | "native_fallback" | "bypassed" | "unavailable";
export type MusicDspVerificationMode = "off" | "eq" | "spatial";
export type MusicEqTopology = "minimum_phase" | "linear_phase";
export type MusicHeadphoneMode = "off" | "wide" | "spatial" | "stage" | "focus" | "bass_impact";
export type MusicOutputProfile = "reference" | "car_hifi" | "headphones" | "speaker";
export type MusicTransitionMode = "auto" | "gapless" | "smooth" | "off";

export const MUSIC_EQ_FREQUENCIES = [
  20, 25, 31.5, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500,
  630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000,
  10000, 12500, 16000, 20000,
] as const;

const LEGACY_EQ_FREQUENCIES = [
  60, 120, 250, 500, 1000, 2000, 4000, 8000, 12000, 16000,
] as const;

type BuiltInMusicEqPreset = Exclude<MusicEqPreset, "custom" | MusicCustomPresetSlot>;
type EqDefinition = { label: string; gains: number[]; preamp: number };

function interpolateEqCurve(points: Array<[number, number]>) {
  const sorted = [...points].sort((a, b) => a[0] - b[0]);
  return MUSIC_EQ_FREQUENCIES.map((frequency) => {
    if (frequency <= sorted[0][0]) return sorted[0][1];
    if (frequency >= sorted[sorted.length - 1][0]) return sorted[sorted.length - 1][1];
    for (let index = 0; index < sorted.length - 1; index += 1) {
      const [leftHz, leftGain] = sorted[index];
      const [rightHz, rightGain] = sorted[index + 1];
      if (frequency < leftHz || frequency > rightHz) continue;
      const ratio =
        (Math.log(frequency) - Math.log(leftHz)) /
        Math.max(0.0001, Math.log(rightHz) - Math.log(leftHz));
      return Math.round((leftGain + (rightGain - leftGain) * ratio) * 10) / 10;
    }
    return 0;
  });
}

function preset(label: string, preamp: number, points: Array<[number, number]>): EqDefinition {
  return { label, preamp, gains: interpolateEqCurve(points) };
}

export const MUSIC_EQ_PRESETS: Record<BuiltInMusicEqPreset, EqDefinition> = {
  flat: preset("Flat", 0, [[20, 0], [20000, 0]]),
  power: preset("Power Training", -1.8, [[20, 1.5], [50, 3.3], [100, 2.8], [250, 0.8], [500, -0.5], [1000, 0], [2500, 1.5], [5000, 2.7], [10000, 2.1], [20000, 0.7]]),
  rock: preset("Rock", -1.6, [[20, 1.0], [63, 2.8], [160, 2.0], [500, -0.7], [1000, 0], [2500, 1.5], [5000, 2.5], [10000, 2.0], [20000, 0.7]]),
  hard_rock: preset("Hard Rock", -2.0, [[20, 1.2], [63, 3.2], [125, 2.5], [400, -1.0], [1000, 0], [2500, 2.0], [5000, 3.0], [10000, 2.3], [20000, 0.8]]),
  metal: preset("Metal", -2.1, [[20, 1.3], [63, 2.9], [160, 1.6], [400, -1.3], [800, -0.6], [2000, 1.8], [4000, 2.9], [8000, 2.8], [16000, 1.4], [20000, 0.5]]),
  alternative: preset("Alternative", -1.5, [[20, 0.6], [80, 2.2], [200, 1.4], [500, -0.7], [1250, 0.4], [3150, 1.9], [6300, 2.1], [12500, 1.2], [20000, 0]]),
  pop: preset("Pop", -1.4, [[20, 0.5], [80, 1.8], [250, 0.4], [630, -0.3], [1600, 1.0], [4000, 2.0], [8000, 1.9], [16000, 0.9], [20000, 0]]),
  hip_hop: preset("Hip-Hop", -2.4, [[20, 2.6], [40, 4.2], [80, 3.8], [160, 2.1], [400, -0.7], [1000, 0], [2500, 0.7], [6300, 1.2], [12500, 0.7], [20000, 0]]),
  edm: preset("EDM", -2.8, [[20, 3.0], [40, 4.7], [80, 3.8], [200, 0.8], [500, -0.7], [1250, 0], [3150, 1.3], [6300, 2.5], [10000, 2.7], [16000, 1.5], [20000, 0.5]]),
  bass_boost: preset("Bass Boost", -2.5, [[20, 3.4], [40, 4.4], [63, 4.5], [100, 3.8], [160, 2.2], [250, 0.8], [500, 0], [20000, 0]]),
  deep_bass: preset("Deep Bass", -3.0, [[20, 4.5], [31.5, 5.5], [50, 4.8], [80, 3.6], [125, 2.1], [250, 0.8], [500, 0], [20000, 0]]),
  punch: preset("Punch", -2.0, [[20, 0.7], [50, 2.2], [80, 3.4], [125, 2.8], [200, 1.3], [500, -0.7], [1000, 0], [3150, 1.8], [6300, 1.3], [20000, 0]]),
  vocal: preset("Vocal Clarity", -1.2, [[20, -2.2], [100, -1.4], [250, -0.4], [630, 0.7], [1250, 1.6], [2500, 2.7], [4000, 2.3], [8000, 0.8], [16000, 0], [20000, -0.5]]),
  acoustic: preset("Acoustic", -1.1, [[20, -1.4], [80, 0], [200, 0.7], [500, 0.4], [1000, 0.7], [2500, 1.5], [5000, 1.8], [10000, 1.1], [20000, 0]]),
  warm: preset("Warm", -1.1, [[20, 0.7], [80, 1.7], [250, 1.3], [630, 0.6], [1600, 0], [4000, -0.7], [10000, -1.3], [20000, -1.6]]),
  bright: preset("Bright", -1.7, [[20, -0.7], [100, 0], [500, 0], [1250, 0.7], [3150, 1.6], [6300, 2.5], [12500, 2.4], [20000, 1.4]]),
  late_night: preset("Late Night", -2.0, [[20, 0.6], [63, 1.2], [160, 0.6], [630, 0], [2500, -0.7], [5000, -1.3], [10000, -2.4], [20000, -3.2]]),
  headphones: preset("Headphones", -1.3, [[20, 0.5], [63, 1.3], [200, 0.3], [630, -0.3], [1600, 0.7], [4000, 1.3], [8000, 0.9], [16000, 0], [20000, -0.5]]),
};
type ProPeak = { frequency: number; gain: number; q: number };
type ProPresetDefinition = {
  highpassHz: number;
  lowShelfHz: number;
  lowShelfDb: number;
  peaks: ProPeak[];
  highShelfHz: number;
  highShelfDb: number;
  makeupDb: number;
  transientAmount: number;
};

type OutputTuningDefinition = {
  highpassHz: number;
  lowShelfHz: number;
  lowShelfDb: number;
  presenceHz: number;
  presenceDb: number;
  presenceQ: number;
  clarityHz: number;
  clarityDb: number;
  clarityQ: number;
  highShelfHz: number;
  highShelfDb: number;
  makeupDb: number;
};

const PRO_PRESET_DEFAULT: ProPresetDefinition = {
  highpassHz: 18,
  lowShelfHz: 90,
  lowShelfDb: 0,
  peaks: [],
  highShelfHz: 12000,
  highShelfDb: 0,
  makeupDb: 0,
  transientAmount: 0,
};

const DSP_EQ_PROOF_PRESET: ProPresetDefinition = {
  highpassHz: 28,
  lowShelfHz: 100,
  lowShelfDb: -5.5,
  peaks: [
    { frequency: 300, gain: -5.0, q: 0.9 },
    { frequency: 1000, gain: -10.0, q: 0.82 },
    { frequency: 3500, gain: 7.0, q: 0.95 },
    { frequency: 7600, gain: 5.0, q: 1.0 },
  ],
  highShelfHz: 11000,
  highShelfDb: 3.0,
  makeupDb: 0,
  transientAmount: 0,
};

// V13.8 tonal engine. These are intentionally moderate, mastering-style curves.
// The 120–350 Hz body region is preserved; output profiles no longer carry a second heavy EQ curve.
const MUSIC_PRO_PRESETS: Record<BuiltInMusicEqPreset, ProPresetDefinition> = {
  flat: { ...PRO_PRESET_DEFAULT },
  power: { ...PRO_PRESET_DEFAULT, transientAmount: 0.64 },
  rock: { ...PRO_PRESET_DEFAULT, transientAmount: 0.42 },
  hard_rock: { ...PRO_PRESET_DEFAULT, transientAmount: 0.62 },
  metal: { ...PRO_PRESET_DEFAULT, transientAmount: 0.70 },
  alternative: { ...PRO_PRESET_DEFAULT, transientAmount: 0.34 },
  pop: { ...PRO_PRESET_DEFAULT, transientAmount: 0.30 },
  hip_hop: { ...PRO_PRESET_DEFAULT, transientAmount: 0.25 },
  edm: { ...PRO_PRESET_DEFAULT, transientAmount: 0.44 },
  bass_boost: { ...PRO_PRESET_DEFAULT, transientAmount: 0.14 },
  deep_bass: { ...PRO_PRESET_DEFAULT, transientAmount: 0.10 },
  punch: { ...PRO_PRESET_DEFAULT, transientAmount: 0.72 },
  vocal: { ...PRO_PRESET_DEFAULT, transientAmount: 0.18 },
  acoustic: { ...PRO_PRESET_DEFAULT, transientAmount: 0.20 },
  warm: { ...PRO_PRESET_DEFAULT, transientAmount: 0.06 },
  bright: { ...PRO_PRESET_DEFAULT, transientAmount: 0.16 },
  late_night: { ...PRO_PRESET_DEFAULT, transientAmount: 0.03 },
  headphones: { ...PRO_PRESET_DEFAULT, transientAmount: 0.16 },
};

type StudioPresetPersonality = {
  transientScale: number;
  multibandAmount: number;
  dynamicEqAmount: number;
  outputCorrectionAmount: number;
  stereoIntegrityAmount: number;
};
const STUDIO_PRESET_PERSONALITIES: Record<BuiltInMusicEqPreset, StudioPresetPersonality> = {
  flat:        { transientScale: 0.65, multibandAmount: 0.42, dynamicEqAmount: 0.42, outputCorrectionAmount: 0.72, stereoIntegrityAmount: 0.55 },
  power:       { transientScale: 0.96, multibandAmount: 0.72, dynamicEqAmount: 0.66, outputCorrectionAmount: 0.84, stereoIntegrityAmount: 0.68 },
  rock:        { transientScale: 0.88, multibandAmount: 0.54, dynamicEqAmount: 0.50, outputCorrectionAmount: 0.78, stereoIntegrityAmount: 0.60 },
  hard_rock:   { transientScale: 0.96, multibandAmount: 0.66, dynamicEqAmount: 0.66, outputCorrectionAmount: 0.82, stereoIntegrityAmount: 0.64 },
  metal:       { transientScale: 1.00, multibandAmount: 0.72, dynamicEqAmount: 0.76, outputCorrectionAmount: 0.82, stereoIntegrityAmount: 0.68 },
  alternative: { transientScale: 0.84, multibandAmount: 0.52, dynamicEqAmount: 0.55, outputCorrectionAmount: 0.76, stereoIntegrityAmount: 0.60 },
  pop:         { transientScale: 0.78, multibandAmount: 0.50, dynamicEqAmount: 0.48, outputCorrectionAmount: 0.76, stereoIntegrityAmount: 0.58 },
  hip_hop:     { transientScale: 0.70, multibandAmount: 0.62, dynamicEqAmount: 0.44, outputCorrectionAmount: 0.84, stereoIntegrityAmount: 0.58 },
  edm:         { transientScale: 0.82, multibandAmount: 0.68, dynamicEqAmount: 0.52, outputCorrectionAmount: 0.84, stereoIntegrityAmount: 0.60 },
  bass_boost:  { transientScale: 0.60, multibandAmount: 0.58, dynamicEqAmount: 0.40, outputCorrectionAmount: 0.88, stereoIntegrityAmount: 0.55 },
  deep_bass:   { transientScale: 0.52, multibandAmount: 0.54, dynamicEqAmount: 0.36, outputCorrectionAmount: 0.90, stereoIntegrityAmount: 0.52 },
  punch:       { transientScale: 1.00, multibandAmount: 0.68, dynamicEqAmount: 0.54, outputCorrectionAmount: 0.80, stereoIntegrityAmount: 0.60 },
  vocal:       { transientScale: 0.56, multibandAmount: 0.42, dynamicEqAmount: 0.54, outputCorrectionAmount: 0.72, stereoIntegrityAmount: 0.55 },
  acoustic:    { transientScale: 0.58, multibandAmount: 0.38, dynamicEqAmount: 0.34, outputCorrectionAmount: 0.68, stereoIntegrityAmount: 0.50 },
  warm:        { transientScale: 0.42, multibandAmount: 0.36, dynamicEqAmount: 0.30, outputCorrectionAmount: 0.68, stereoIntegrityAmount: 0.50 },
  bright:      { transientScale: 0.50, multibandAmount: 0.42, dynamicEqAmount: 0.56, outputCorrectionAmount: 0.72, stereoIntegrityAmount: 0.54 },
  late_night:  { transientScale: 0.28, multibandAmount: 0.32, dynamicEqAmount: 0.26, outputCorrectionAmount: 0.66, stereoIntegrityAmount: 0.46 },
  headphones:  { transientScale: 0.52, multibandAmount: 0.38, dynamicEqAmount: 0.36, outputCorrectionAmount: 0.68, stereoIntegrityAmount: 0.50 },
};
const STUDIO_CUSTOM_PERSONALITY: StudioPresetPersonality = {
  transientScale: 0.78,
  multibandAmount: 0.52,
  dynamicEqAmount: 0.50,
  outputCorrectionAmount: 0.76,
  stereoIntegrityAmount: 0.58,
};
function currentStudioPersonality(): StudioPresetPersonality {
  return isBuiltInPreset(state.eqPreset) ? STUDIO_PRESET_PERSONALITIES[state.eqPreset] : STUDIO_CUSTOM_PERSONALITY;
}
// MVP_STUDIO_V4_MASTERING_REFINEMENT
// Output profiles are technical device paths, not a second musical EQ.
const MUSIC_OUTPUT_TUNINGS: Record<Exclude<MusicOutputProfile, "reference">, OutputTuningDefinition> = {
  car_hifi: { highpassHz: 18, lowShelfHz: 80, lowShelfDb: 0.15, presenceHz: 320, presenceDb: 0, presenceQ: 0.82, clarityHz: 3000, clarityDb: 0.15, clarityQ: 0.9, highShelfHz: 12000, highShelfDb: 0.10, makeupDb: 0 },
  headphones: { highpassHz: 18, lowShelfHz: 90, lowShelfDb: 0, presenceHz: 320, presenceDb: 0, presenceQ: 0.82, clarityHz: 3000, clarityDb: 0, clarityQ: 0.9, highShelfHz: 12000, highShelfDb: 0, makeupDb: 0 },
  speaker: { highpassHz: 28, lowShelfHz: 90, lowShelfDb: 0, presenceHz: 320, presenceDb: 0, presenceQ: 0.82, clarityHz: 3500, clarityDb: 0.20, clarityQ: 0.9, highShelfHz: 12000, highShelfDb: 0.30, makeupDb: 0 },
};

export const MUSIC_HEADPHONE_MODES: Record<
  MusicHeadphoneMode,
  { label: string; width: number; depth: number; crossfeed: number; center: number; bass: number }
> = {
  off: { label: "Off", width: 0, depth: 0, crossfeed: 0, center: 50, bass: 0 },
  wide: { label: "Wide", width: 100, depth: 8, crossfeed: 2, center: 48, bass: 4 },
  spatial: { label: "Spatial", width: 92, depth: 95, crossfeed: 18, center: 54, bass: 6 },
  stage: { label: "Stage", width: 58, depth: 82, crossfeed: 62, center: 72, bass: 8 },
  focus: { label: "Focus", width: 0, depth: 0, crossfeed: 30, center: 100, bass: 0 },
  bass_impact: { label: "Bass Impact", width: 46, depth: 16, crossfeed: 8, center: 60, bass: 90 },
};
// MVP_STUDIO_V4_5_HEADPHONE_CONTINUITY
export const MUSIC_OUTPUT_PROFILES: Record<
  MusicOutputProfile,
  { label: string; shortLabel: string; description: string }
> = {
  reference: {
    label: "Reference",
    shortLabel: "REF",
    description: "Direct reference path for level-matched A/B checks with processing removed.",
  },
  car_hifi: {
    label: "Car / Hi-Fi",
    shortLabel: "CAR / HI-FI",
    description: "Near-neutral full-range path with conservative gain and true-peak protection for a tuned vehicle or hi-fi system.",
  },
  headphones: {
    label: "Headphones",
    shortLabel: "HEADPHONES",
    description: "Near-neutral headphone path with optional binaural crossfeed, spatial processing and transparent true-peak protection.",
  },
  speaker: {
    label: "Bluetooth Speaker",
    shortLabel: "BLUETOOTH",
    description: "Near-neutral Bluetooth path with gentle codec-detail compensation and no heavy bass removal.",
  },
};

export type MusicPlayerState = {
  libraryTracks: MusicTrack[];
  tracks: MusicTrack[];
  currentTrack: MusicTrack | null;
  activePlaylistId: string | null;
  activePlaylistName: string | null;
  loading: boolean;
  playing: boolean;
  currentTime: number;
  duration: number;
  shuffle: boolean;
  repeat: MusicRepeatMode;
  error: string | null;
  libraryLoaded: boolean;
  volume: number;
  eqEnabled: boolean;
  eqPreset: MusicEqPreset;
  eqGains: number[];
  eqTopology: MusicEqTopology;
  preampDb: number;
  effectivePreampDb: number;
  autoHeadroomDb: number;
  crossfadeSeconds: number;
  transitionMode: MusicTransitionMode;
  normalizationEnabled: boolean;
  multibandEnabled: boolean;
  dynamicEqEnabled: boolean;
  dynamicEqGainReductionDb: number;
  dynamicEqBandReductionDb: [number, number, number, number];
  outputCorrectionReductionDb: number;
  // MVP_STUDIO_WASM_V3_PHASE6_STEREO_INTEGRITY
  stereoCorrelation: number;
  stereoWidthPercent: number;
  stereoGuardReductionDb: number;
  loudnessGainDb: number;
  loudnessMomentaryLufs: number;
  // MVP_STUDIO_WASM_V3_PHASE5_LIVE_METERING
  truePeakDbtp: number;
  limiterGainReductionDb: number;
  transientBoostDb: number;
  multibandGainReductionDb: number;
  limiterEnabled: boolean;
  duckingStrength: MusicDuckingStrength;
  headphoneMode: MusicHeadphoneMode;
  headphoneWidth: number;
  headphoneDepth: number;
  headphoneCrossfeed: number;
  headphoneCenter: number;
  headphoneBassImpact: number;
  outputProfile: MusicOutputProfile;
  dspBypass: boolean;
  dspStatus: MusicDspStatus;
  dspEngineMode: MusicDspEngineMode;
  immersionStatus: MusicImmersionStatus;
  dspVerificationMode: MusicDspVerificationMode;
};

const STORAGE_KEYS = {
  currentTrackId: "mvp_music_current_track_id",
  currentTime: "mvp_music_current_time",
  shuffle: "mvp_music_shuffle",
  repeat: "mvp_music_repeat",
  activePlaylistId: "mvp_music_active_playlist_id",
  activePlaylistName: "mvp_music_active_playlist_name",
  activeQueueTrackIds: "mvp_music_active_queue_track_ids_v1",
  volume: "mvp_music_volume_v2",
  eqEnabled: "mvp_music_eq_enabled",
  eqPreset: "mvp_music_eq_preset",
  eqGains: "mvp_music_eq_gains",
  eqTopology: "mvp_music_eq_topology_v13_8",
  preampDb: "mvp_music_eq_preamp_db",
  crossfadeSeconds: "mvp_music_crossfade_seconds",
  transitionMode: "mvp_music_transition_mode_v1",
  normalizationEnabled: "mvp_music_volume_match_enabled_v1",
  multibandEnabled: "mvp_music_multiband_enabled_v13_9",
  dynamicEqEnabled: "mvp_music_dynamic_eq_enabled_v1",
  limiterEnabled: "mvp_music_limiter_enabled",
  duckingStrength: "mvp_music_ducking_strength",
  headphoneMode: "mvp_music_headphone_mode",
  headphoneWidth: "mvp_music_headphone_width",
  headphoneDepth: "mvp_music_headphone_depth",
  headphoneCrossfeed: "mvp_music_headphone_crossfeed",
  headphoneCenter: "mvp_music_headphone_center",
  headphoneBassImpact: "mvp_music_headphone_bass_impact",
  outputProfile: "mvp_music_output_profile_v12",
  dspBypass: "mvp_music_dsp_bypass",
  audioEngineVersion: "mvp_music_audio_engine_version",
  custom1: "mvp_music_eq_custom_1",
  custom2: "mvp_music_eq_custom_2",
  custom3: "mvp_music_eq_custom_3",
} as const;

const AUDIO_ENGINE_VERSION = "v14-4-r9-2-hrtf-gain-verified";
const listeners = new Set<() => void>();

function readStored(key: string) {
  try {
    return typeof localStorage === "undefined" ? "" : localStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}
function savePlayerSetting(key: string, value: string) {
  try {
    if (typeof localStorage !== "undefined") localStorage.setItem(key, value);
  } catch {
    /* optional */
  }
}
function removePlayerSetting(key: string) {
  try {
    if (typeof localStorage !== "undefined") localStorage.removeItem(key);
  } catch {
    /* optional */
  }
}
function readBoolean(key: string, fallback = false) {
  const value = readStored(key);
  return value ? value === "true" : fallback;
}
function readNumber(key: string, fallback: number, min: number, max: number) {
  const raw = readStored(key);
  if (!raw) return fallback;
  const value = Number(raw);
  return Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
}
function readRepeatMode(): MusicRepeatMode {
  const value = readStored(STORAGE_KEYS.repeat);
  return value === "one" || value === "all" ? value : "off";
}
function readDuckingStrength(): MusicDuckingStrength {
  const value = readStored(STORAGE_KEYS.duckingStrength);
  return value === "off" || value === "light" || value === "standard" || value === "strong"
    ? value
    : "standard";
}
function isCustomPresetSlot(value: MusicEqPreset): value is MusicCustomPresetSlot {
  return value === "custom_1" || value === "custom_2" || value === "custom_3";
}
function isBuiltInPreset(value: MusicEqPreset): value is BuiltInMusicEqPreset {
  return Object.prototype.hasOwnProperty.call(MUSIC_EQ_PRESETS, value);
}
function customPresetStorageKey(slot: MusicCustomPresetSlot) {
  return slot === "custom_1"
    ? STORAGE_KEYS.custom1
    : slot === "custom_2"
      ? STORAGE_KEYS.custom2
      : STORAGE_KEYS.custom3;
}
function readCustomPreset(slot: MusicCustomPresetSlot): EqDefinition | null {
  try {
    const raw = readStored(customPresetStorageKey(slot));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { gains?: unknown[]; preamp?: unknown };
    if (
      Array.isArray(parsed.gains) &&
      parsed.gains.length === MUSIC_EQ_FREQUENCIES.length &&
      parsed.gains.every((value) => Number.isFinite(Number(value))) &&
      Number.isFinite(Number(parsed.preamp))
    ) {
      return {
        label: slot === "custom_1" ? "Custom 1" : slot === "custom_2" ? "Custom 2" : "Custom 3",
        gains: parsed.gains.map((value) => Math.max(-12, Math.min(12, Number(value)))),
        preamp: Math.max(-12, Math.min(6, Number(parsed.preamp))),
      };
    }
  } catch {
    /* empty */
  }
  return null;
}
function readEqPreset(): MusicEqPreset {
  const value = readStored(STORAGE_KEYS.eqPreset) as MusicEqPreset;
  return value === "custom" || isCustomPresetSlot(value) || isBuiltInPreset(value) ? value : "flat";
}
function interpolateLegacyEqGains(values: number[]) {
  return interpolateEqCurve(
    LEGACY_EQ_FREQUENCIES.map(
      (frequency, index) =>
        [frequency, Math.max(-12, Math.min(12, Number(values[index] || 0)))] as [number, number],
    ),
  );
}
function readEqGains(presetName: MusicEqPreset) {
  try {
    const raw = readStored(STORAGE_KEYS.eqGains);
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed) && parsed.every((value) => Number.isFinite(Number(value)))) {
      if (parsed.length === MUSIC_EQ_FREQUENCIES.length) {
        return parsed.map((value) => Math.max(-12, Math.min(12, Number(value))));
      }
      if (parsed.length === LEGACY_EQ_FREQUENCIES.length) return interpolateLegacyEqGains(parsed.map(Number));
    }
  } catch {
    /* preset below */
  }
  if (isCustomPresetSlot(presetName)) {
    return [...(readCustomPreset(presetName)?.gains ?? MUSIC_EQ_PRESETS.flat.gains)];
  }
  if (isBuiltInPreset(presetName)) return [...MUSIC_EQ_PRESETS[presetName].gains];
  return [...MUSIC_EQ_PRESETS.flat.gains];
}
function readPreamp(presetName: MusicEqPreset) {
  const raw = readStored(STORAGE_KEYS.preampDb);
  if (raw) {
    const value = Number(raw);
    if (Number.isFinite(value)) return Math.max(-12, Math.min(6, value));
  }
  if (isCustomPresetSlot(presetName)) return readCustomPreset(presetName)?.preamp ?? 0;
  return isBuiltInPreset(presetName) ? MUSIC_EQ_PRESETS[presetName].preamp : 0;
}
function readHeadphoneMode(): MusicHeadphoneMode {
  const value = readStored(STORAGE_KEYS.headphoneMode) as MusicHeadphoneMode;
  return Object.prototype.hasOwnProperty.call(MUSIC_HEADPHONE_MODES, value) ? value : "off";
}
function readOutputProfile(): MusicOutputProfile {
  const value = readStored(STORAGE_KEYS.outputProfile) as MusicOutputProfile;
  return value === "reference" || value === "car_hifi" || value === "headphones" || value === "speaker"
    ? value
    : "car_hifi";
}
function readEqTopology(): MusicEqTopology {
  return readStored(STORAGE_KEYS.eqTopology) === "linear_phase" ? "linear_phase" : "minimum_phase";
}
function readTransitionMode(): MusicTransitionMode {
  const value = readStored(STORAGE_KEYS.transitionMode);
  return value === "gapless" || value === "smooth" || value === "off" ? value : "auto";
}

function migrateAudioFidelitySettings() {
  if (readStored(STORAGE_KEYS.audioEngineVersion) === AUDIO_ENGINE_VERSION) return;
  const presetName = readEqPreset();
  if (isBuiltInPreset(presetName)) {
    const definition = MUSIC_EQ_PRESETS[presetName];
    savePlayerSetting(STORAGE_KEYS.eqGains, JSON.stringify(definition.gains));
    savePlayerSetting(STORAGE_KEYS.preampDb, String(definition.preamp));
  } else if (isCustomPresetSlot(presetName)) {
    const definition = readCustomPreset(presetName);
    if (definition) {
      savePlayerSetting(STORAGE_KEYS.eqGains, JSON.stringify(definition.gains));
      savePlayerSetting(STORAGE_KEYS.preampDb, String(definition.preamp));
    }
  }
  if (!readStored(STORAGE_KEYS.eqTopology)) savePlayerSetting(STORAGE_KEYS.eqTopology, "minimum_phase");
  // Core Studio processing starts active, but Volume Match is an optional utility.
  // It stays OFF unless the user explicitly enables track-to-track leveling.
  savePlayerSetting(STORAGE_KEYS.eqEnabled, "true");
  savePlayerSetting(STORAGE_KEYS.normalizationEnabled, "false");
  savePlayerSetting(STORAGE_KEYS.multibandEnabled, "true");
  savePlayerSetting(STORAGE_KEYS.limiterEnabled, "true");
  savePlayerSetting(STORAGE_KEYS.dspBypass, "false");
  savePlayerSetting(STORAGE_KEYS.audioEngineVersion, AUDIO_ENGINE_VERSION);
}

migrateAudioFidelitySettings();
const initialPreset = readEqPreset();

let state: MusicPlayerState = {
  libraryTracks: [],
  tracks: [],
  currentTrack: null,
  activePlaylistId: readStored(STORAGE_KEYS.activePlaylistId) || null,
  activePlaylistName: readStored(STORAGE_KEYS.activePlaylistName) || null,
  loading: false,
  playing: false,
  currentTime: 0,
  duration: 0,
  shuffle: readBoolean(STORAGE_KEYS.shuffle),
  repeat: readRepeatMode(),
  error: null,
  libraryLoaded: false,
  volume: readNumber(STORAGE_KEYS.volume, 0.72, 0, 1),
  eqEnabled: readBoolean(STORAGE_KEYS.eqEnabled, true),
  eqPreset: initialPreset,
  eqGains: readEqGains(initialPreset),
  eqTopology: readEqTopology(),
  preampDb: readPreamp(initialPreset),
  effectivePreampDb: 0,
  autoHeadroomDb: 0,
  crossfadeSeconds: readNumber(STORAGE_KEYS.crossfadeSeconds, 0, 0, 8),
  transitionMode: readTransitionMode(),
  normalizationEnabled: readBoolean(STORAGE_KEYS.normalizationEnabled, false),
  multibandEnabled: readBoolean(STORAGE_KEYS.multibandEnabled, true),
  dynamicEqEnabled: readBoolean(STORAGE_KEYS.dynamicEqEnabled, true),
  dynamicEqGainReductionDb: 0,
  dynamicEqBandReductionDb: [0, 0, 0, 0],
  outputCorrectionReductionDb: 0,
  stereoCorrelation: 1,
  stereoWidthPercent: 100,
  stereoGuardReductionDb: 0,
  loudnessGainDb: 0,
  loudnessMomentaryLufs: -70,
  truePeakDbtp: -120,
  limiterGainReductionDb: 0,
  transientBoostDb: 0,
  multibandGainReductionDb: 0,
  limiterEnabled: readBoolean(STORAGE_KEYS.limiterEnabled, true),
  duckingStrength: readDuckingStrength(),
  headphoneMode: readHeadphoneMode(),
  headphoneWidth: readNumber(STORAGE_KEYS.headphoneWidth, 0, 0, 100),
  headphoneDepth: readNumber(STORAGE_KEYS.headphoneDepth, 0, 0, 100),
  headphoneCrossfeed: readNumber(STORAGE_KEYS.headphoneCrossfeed, 0, 0, 100),
  headphoneCenter: readNumber(STORAGE_KEYS.headphoneCenter, 50, 0, 100),
  headphoneBassImpact: readNumber(STORAGE_KEYS.headphoneBassImpact, 0, 0, 100),
  outputProfile: readOutputProfile(),
  dspBypass: readBoolean(STORAGE_KEYS.dspBypass, false),
  dspStatus: "recovering",
  dspEngineMode: "unavailable",
  immersionStatus: "bypassed",
  dspVerificationMode: "off",
};

let audioElement: HTMLAudioElement | null = null;
let audioContext: AudioContext | null = null;
let mediaSource: MediaElementAudioSourceNode | null = null;
let masterVolumeGain: GainNode | null = null;
let referenceRouteGain: GainNode | null = null;
let preampGain: GainNode | null = null;
let studioProcessorNode: AudioWorkletNode | null = null;
let transientProcessorNode: AudioWorkletNode | null = null;
let loudnessNormalizerNode: AudioWorkletNode | null = null;
let multibandProcessorNode: AudioWorkletNode | null = null;
let professionalHighpass: BiquadFilterNode | null = null;
let professionalLowShelf: BiquadFilterNode | null = null;
let professionalPeakFilters: BiquadFilterNode[] = [];
let professionalHighShelf: BiquadFilterNode | null = null;
let equalizerFilters: BiquadFilterNode[] = [];
let linearPhaseEqNode: AudioWorkletNode | null = null;
let outputHighpass: BiquadFilterNode | null = null;
let outputLowShelf: BiquadFilterNode | null = null;
let outputPresence: BiquadFilterNode | null = null;
let outputClarity: BiquadFilterNode | null = null;
let outputHighShelf: BiquadFilterNode | null = null;
let standardRouteGain: GainNode | null = null;
// Studio headphone virtualization uses two browser HRTF virtual loudspeakers before the WASM mastering/limiter path.
let studioDirectInputGain: GainNode | null = null;
let studioHrtfSplitter: ChannelSplitterNode | null = null;
let studioHrtfLeftPanner: PannerNode | null = null;
let studioHrtfRightPanner: PannerNode | null = null;
let studioHrtfSum: GainNode | null = null;
let studioHrtfBassShelf: BiquadFilterNode | null = null;
let studioHrtfReflectionDelayA: DelayNode | null = null;
let studioHrtfReflectionDelayB: DelayNode | null = null;
let studioHrtfReflectionGainA: GainNode | null = null;
let studioHrtfReflectionGainB: GainNode | null = null;
let studioHrtfInputGain: GainNode | null = null;
let studioInputBus: GainNode | null = null;
let headphoneProcessorNode: AudioWorkletNode | null = null;
let nativeHeadphoneBassShelf: BiquadFilterNode | null = null;
let nativeHeadphoneSplitter: ChannelSplitterNode | null = null;
let nativeHeadphoneMerger: ChannelMergerNode | null = null;
let nativeHeadphoneLeftDirect: GainNode | null = null;
let nativeHeadphoneRightDirect: GainNode | null = null;
let nativeHeadphoneLeftWidthCross: GainNode | null = null;
let nativeHeadphoneRightWidthCross: GainNode | null = null;
let nativeHeadphoneLeftCrossDelay: DelayNode | null = null;
let nativeHeadphoneRightCrossDelay: DelayNode | null = null;
let nativeHeadphoneLeftCrossLowpass: BiquadFilterNode | null = null;
let nativeHeadphoneRightCrossLowpass: BiquadFilterNode | null = null;
let nativeHeadphoneLeftCrossGain: GainNode | null = null;
let nativeHeadphoneRightCrossGain: GainNode | null = null;
let nativeHeadphoneLeftDepthDelay: DelayNode | null = null;
let nativeHeadphoneRightDepthDelay: DelayNode | null = null;
let nativeHeadphoneLeftDepthGain: GainNode | null = null;
let nativeHeadphoneRightDepthGain: GainNode | null = null;
let nativeHeadphoneCenterSum: GainNode | null = null;
let nativeHeadphoneCenterLeft: GainNode | null = null;
let nativeHeadphoneCenterRight: GainNode | null = null;
let headphoneRouteGain: GainNode | null = null;
let mixBus: GainNode | null = null;
let makeupGain: GainNode | null = null;
let limiterWorkletNode: AudioWorkletNode | null = null;
let limiterFallbackNode: DynamicsCompressorNode | null = null;
let analyserNode: AnalyserNode | null = null;
let referenceLevelAnalyser: AnalyserNode | null = null;
let processedLevelAnalyser: AnalyserNode | null = null;
let levelMeterSink: GainNode | null = null;
let musicGain: GainNode | null = null;
let analyserBuffer: Uint8Array<ArrayBuffer> | null = null;
let visualizerEnvelope = new Float32Array(64);
let mediaSourceConnected = false;
let graphBuildPromise: Promise<void> | null = null;
let loadingTrackId: string | null = null;
let transitionPreloadAudio: HTMLAudioElement | null = null;
let transitionPreloadTrackId: string | null = null;
let transitionPreloadUrl: string | null = null;
let studioRecoveryInFlight = false;
let lastStudioRecoveryAt = 0;
let timeSaveTimer = 0;
let recordedPlayToken = "";
let transportQueue: Promise<void> = Promise.resolve();
let playbackIntent = false;
let lastDspStatus: MusicDspStatus = "recovering";
let lastHeadroom = -1;
let lastEffectivePreamp = Number.NaN;
let processingSettleTimer = 0;
let levelMeterTimer = 0;
let lastReferenceRmsDb = Number.NaN;
let lastProcessedRmsDb = Number.NaN;
const signedUrlCache = new Map<string, { url: string; cachedAt: number }>();
const SIGNED_URL_TTL_MS = 8 * 60 * 1000;
const GRAPHIC_EQ_Q = 4.318;
const PRO_PEAK_COUNT = 6;

function emit(patch: Partial<MusicPlayerState>) {
  state = { ...state, ...patch };
  listeners.forEach((listener) => listener());
}
function getAudioContext() {
  if (typeof window === "undefined") return null;
  const Context =
    window.AudioContext ||
    (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Context) return null;
  if (audioContext?.state === "closed") audioContext = null;
  if (!audioContext) audioContext = new Context();
  return audioContext;
}
function dbToGain(db: number) {
  return Math.pow(10, db / 20);
}
function gainToDb(gain: number) {
  return 20 * Math.log10(Math.max(0.000001, gain));
}
function volumeToGain(volume: number) {
  const normalized = Math.max(0, Math.min(1, Number(volume) || 0));
  if (normalized <= 0) return 0;
  // 80% is calibrated unity. The top 20% is protected high-output reserve.
  if (normalized <= 0.8) return normalized / 0.8;
  // Reserve is only available on a protected processed path. Reference / limiter-off stays at unity.
  if (state.outputProfile === "reference" || state.dspBypass || !state.limiterEnabled) return 1;
  const reserve = (normalized - 0.8) / 0.2;
  return dbToGain(reserve * 8);
}
function setAudioParam(param: AudioParam, value: number, now: number, timeConstant = 0.018) {
  param.cancelScheduledValues(now);
  param.setTargetAtTime(value, now, timeConstant);
}
function setCompressorBypass(node: DynamicsCompressorNode) {
  node.threshold.value = 0;
  node.knee.value = 0;
  node.ratio.value = 1;
  node.attack.value = 0.003;
  node.release.value = 0.12;
}
function eqProcessingRequested() {
  return state.outputProfile !== "reference" && state.eqEnabled;
}
function eqProofActive() {
  return state.dspVerificationMode === "eq" && state.outputProfile !== "reference" && !state.dspBypass;
}
function graphicEqProcessingRequested() {
  // The visible 31-band curve is the tonal source of truth for built-in presets,
  // custom presets, and manual edits. No hidden duplicate preset EQ is layered on top.
  return eqProcessingRequested() && !eqProofActive();
}
function professionalProcessingRequested() {
  // The legacy professional filter bank is retained only for the explicit EQ proof tool.
  return eqProofActive();
}
function currentProPreset() {
  return eqProofActive() ? DSP_EQ_PROOF_PRESET : MUSIC_PRO_PRESETS.flat;
}
function currentTransientAmount() {
  if (eqProofActive()) return 0;
  if (!eqProcessingRequested() || !isBuiltInPreset(state.eqPreset)) return 0;
  return MUSIC_PRO_PRESETS[state.eqPreset].transientAmount;
}
function currentOutputTuning() {
  return state.outputProfile === "reference" ? null : MUSIC_OUTPUT_TUNINGS[state.outputProfile];
}
function clampFilterFrequency(context: AudioContext, frequency: number) {
  return Math.max(10, Math.min(frequency, context.sampleRate * 0.46));
}
function configureProfessionalFilters(now: number) {
  if (!audioContext) return;
  const definition = currentProPreset();
  if (professionalHighpass) {
    setAudioParam(professionalHighpass.frequency, clampFilterFrequency(audioContext, definition.highpassHz), now, 0.035);
    setAudioParam(professionalHighpass.Q, 0.707, now, 0.035);
  }
  if (professionalLowShelf) {
    setAudioParam(professionalLowShelf.frequency, clampFilterFrequency(audioContext, definition.lowShelfHz), now, 0.035);
    setAudioParam(professionalLowShelf.gain, definition.lowShelfDb, now, 0.035);
  }
  professionalPeakFilters.forEach((filter, index) => {
    const peak = definition.peaks[index];
    setAudioParam(filter.frequency, clampFilterFrequency(audioContext!, peak?.frequency ?? 1000 + index * 500), now, 0.035);
    setAudioParam(filter.Q, peak?.q ?? 1, now, 0.035);
    setAudioParam(filter.gain, peak?.gain ?? 0, now, 0.035);
  });
  if (professionalHighShelf) {
    setAudioParam(professionalHighShelf.frequency, clampFilterFrequency(audioContext, definition.highShelfHz), now, 0.035);
    setAudioParam(professionalHighShelf.gain, definition.highShelfDb, now, 0.035);
  }
}
function buildLinearPhaseFir(gainsDb: number[], sampleRateValue: number) {
  const half = 128;
  const taps = half * 2 + 1;
  const bins = 128;
  const amplitudes = new Float64Array(bins + 1);
  const maxHz = sampleRateValue / 2;
  const minBand = MUSIC_EQ_FREQUENCIES[0];
  const maxBand = MUSIC_EQ_FREQUENCIES[MUSIC_EQ_FREQUENCIES.length - 1];
  const gainAt = (frequency: number) => {
    if (frequency <= minBand) return Number(gainsDb[0] || 0);
    if (frequency >= maxBand) return Number(gainsDb[gainsDb.length - 1] || 0);
    for (let index = 0; index < MUSIC_EQ_FREQUENCIES.length - 1; index += 1) {
      const leftHz = MUSIC_EQ_FREQUENCIES[index];
      const rightHz = MUSIC_EQ_FREQUENCIES[index + 1];
      if (frequency < leftHz || frequency > rightHz) continue;
      const amount = (Math.log(frequency) - Math.log(leftHz)) / Math.max(0.000001, Math.log(rightHz) - Math.log(leftHz));
      const leftDb = Number(gainsDb[index] || 0);
      const rightDb = Number(gainsDb[index + 1] || 0);
      return leftDb + (rightDb - leftDb) * amount;
    }
    return 0;
  };
  for (let bin = 0; bin <= bins; bin += 1) {
    const frequency = (bin / bins) * maxHz;
    amplitudes[bin] = dbToGain(gainAt(Math.max(10, frequency)));
  }
  const coefficients = new Float32Array(taps);
  for (let tap = 0; tap < taps; tap += 1) {
    const m = tap - half;
    let value = 0.5 * amplitudes[0] + 0.5 * amplitudes[bins] * Math.cos(Math.PI * m);
    for (let bin = 1; bin < bins; bin += 1) value += amplitudes[bin] * Math.cos(Math.PI * bin * m / bins);
    value /= bins;
    const window = 0.42 - 0.5 * Math.cos((2 * Math.PI * tap) / (taps - 1)) + 0.08 * Math.cos((4 * Math.PI * tap) / (taps - 1));
    coefficients[tap] = value * window;
  }
  return coefficients;
}
function configureGraphicEq(now: number) {
  const enabled = graphicEqProcessingRequested();
  const minimumPhase = enabled && (state.eqTopology === "minimum_phase" || !linearPhaseEqNode);
  equalizerFilters.forEach((filter, index) => {
    const gain = minimumPhase ? Number(state.eqGains[index] || 0) : 0;
    setAudioParam(filter.gain, gain, now, 0.028);
  });
  if (linearPhaseEqNode) {
    const enabledParam = workletParam(linearPhaseEqNode, "enabled");
    if (enabledParam) setAudioParam(enabledParam, enabled && state.eqTopology === "linear_phase" ? 1 : 0, now, 0.02);
    if (enabled && state.eqTopology === "linear_phase" && audioContext) {
      linearPhaseEqNode.port.postMessage({ type: "coefficients", coefficients: Array.from(buildLinearPhaseFir(state.eqGains, audioContext.sampleRate)) });
    }
  }
}
function configureOutputFilters(now: number) {
  if (!audioContext) return;
  const tuning = currentOutputTuning();
  const highpass = tuning?.highpassHz ?? 10;
  const lowShelfHz = tuning?.lowShelfHz ?? 100;
  const lowShelfDb = tuning?.lowShelfDb ?? 0;
  const presenceHz = tuning?.presenceHz ?? 320;
  const presenceDb = tuning?.presenceDb ?? 0;
  const presenceQ = tuning?.presenceQ ?? 0.8;
  const clarityHz = tuning?.clarityHz ?? 2800;
  const clarityDb = tuning?.clarityDb ?? 0;
  const clarityQ = tuning?.clarityQ ?? 0.9;
  const highShelfHz = tuning?.highShelfHz ?? 10000;
  const highShelfDb = tuning?.highShelfDb ?? 0;
  if (outputHighpass) {
    setAudioParam(outputHighpass.frequency, clampFilterFrequency(audioContext, highpass), now, 0.035);
    setAudioParam(outputHighpass.Q, 0.707, now, 0.035);
  }
  if (outputLowShelf) {
    setAudioParam(outputLowShelf.frequency, clampFilterFrequency(audioContext, lowShelfHz), now, 0.035);
    setAudioParam(outputLowShelf.gain, lowShelfDb, now, 0.035);
  }
  if (outputPresence) {
    setAudioParam(outputPresence.frequency, clampFilterFrequency(audioContext, presenceHz), now, 0.035);
    setAudioParam(outputPresence.Q, presenceQ, now, 0.035);
    setAudioParam(outputPresence.gain, presenceDb, now, 0.035);
  }
  if (outputClarity) {
    setAudioParam(outputClarity.frequency, clampFilterFrequency(audioContext, clarityHz), now, 0.035);
    setAudioParam(outputClarity.Q, clarityQ, now, 0.035);
    setAudioParam(outputClarity.gain, clarityDb, now, 0.035);
  }
  if (outputHighShelf) {
    setAudioParam(outputHighShelf.frequency, clampFilterFrequency(audioContext, highShelfHz), now, 0.035);
    setAudioParam(outputHighShelf.gain, highShelfDb, now, 0.035);
  }
}
function activeResponseFilters() {
  const filters: BiquadFilterNode[] = [];
  if (state.outputProfile === "reference") return filters;
  if (professionalProcessingRequested()) {
    if (professionalHighpass) filters.push(professionalHighpass);
    if (professionalLowShelf) filters.push(professionalLowShelf);
    filters.push(...professionalPeakFilters);
    if (professionalHighShelf) filters.push(professionalHighShelf);
  }
  if (graphicEqProcessingRequested() && (state.eqTopology === "minimum_phase" || !linearPhaseEqNode)) filters.push(...equalizerFilters);
  if (outputHighpass) filters.push(outputHighpass);
  if (outputLowShelf) filters.push(outputLowShelf);
  if (outputPresence) filters.push(outputPresence);
  if (outputClarity) filters.push(outputClarity);
  if (outputHighShelf) filters.push(outputHighShelf);
  return filters;
}
function measureProcessingResponse() {
  if (!audioContext || state.outputProfile === "reference") return { peakDb: 0, averageDb: 0 };
  const filters = activeResponseFilters();
  if (!filters.length) return { peakDb: 0, averageDb: 0 };
  const count = 192;
  const frequencies = new Float32Array(count);
  const maxHz = Math.min(20000, audioContext.sampleRate * 0.45);
  const minHz = 20;
  const ratio = maxHz / minHz;
  for (let index = 0; index < count; index += 1) {
    frequencies[index] = minHz * Math.pow(ratio, index / (count - 1));
  }
  const combined = new Float32Array(count);
  combined.fill(1);
  const magnitude = new Float32Array(count);
  const phase = new Float32Array(count);
  filters.forEach((filter) => {
    filter.getFrequencyResponse(frequencies, magnitude, phase);
    for (let index = 0; index < count; index += 1) combined[index] *= Math.max(0.000001, magnitude[index]);
  });
  let peakDb = -120;
  let weightedTotal = 0;
  let weightTotal = 0;
  for (let index = 0; index < count; index += 1) {
    const db = gainToDb(combined[index]);
    peakDb = Math.max(peakDb, db);
    const frequency = frequencies[index];
    const weight = frequency >= 55 && frequency <= 12000 ? 1 : 0.25;
    weightedTotal += db * weight;
    weightTotal += weight;
  }
  return { peakDb: Math.max(0, peakDb), averageDb: weightTotal ? weightedTotal / weightTotal : 0 };
}
function calculateProcessingGain() {
  if (state.outputProfile === "reference") {
    return { effectivePreampDb: 0, autoHeadroomDb: 0, makeupDb: 0, referenceMatchDb: 0 };
  }
  // R9.2: the Preamp Trim readout is the requested gain. Do not silently subtract
  // EQ-derived headroom from the user control. The protected limiter is the final
  // peak-safety stage on processed paths.
  const requested = eqProcessingRequested()
    ? Math.max(-12, Math.min(6, Number(state.preampDb) || 0))
    : 0;
  const response = measureProcessingResponse();
  const makeupDb = currentOutputTuning()?.makeupDb ?? 0;
  const measuredMatch = Number.isFinite(lastReferenceRmsDb) && Number.isFinite(lastProcessedRmsDb)
    ? Math.max(-6, Math.min(3, lastProcessedRmsDb - lastReferenceRmsDb))
    : Math.max(-6, Math.min(3, requested + response.averageDb + makeupDb));
  return {
    effectivePreampDb: requested,
    autoHeadroomDb: 0,
    makeupDb,
    referenceMatchDb: measuredMatch,
  };
}
function scheduleProcessingSettle() {
  if (typeof window === "undefined") return;
  if (processingSettleTimer) window.clearTimeout(processingSettleTimer);
  processingSettleTimer = window.setTimeout(() => {
    processingSettleTimer = 0;
    applyProcessingSettings();
  }, 140);
}
function setDspTelemetry(status: MusicDspStatus, effectivePreampDb: number, autoHeadroomDb: number) {
  const roundedPreamp = Math.round(effectivePreampDb * 10) / 10;
  const roundedHeadroom = Math.round(autoHeadroomDb * 10) / 10;
  if (
    status === lastDspStatus &&
    roundedHeadroom === lastHeadroom &&
    roundedPreamp === lastEffectivePreamp
  ) {
    return;
  }
  lastDspStatus = status;
  lastHeadroom = roundedHeadroom;
  lastEffectivePreamp = roundedPreamp;
  emit({ dspStatus: status, effectivePreampDb: roundedPreamp, autoHeadroomDb: roundedHeadroom });
}
function workletParam(node: AudioWorkletNode | null, name: string) {
  return node?.parameters.get(name) ?? null;
}
function headphoneModeCode(mode: MusicHeadphoneMode) {
  if (mode === "wide") return 1;
  if (mode === "spatial") return 2;
  if (mode === "stage") return 3;
  if (mode === "focus") return 4;
  if (mode === "bass_impact") return 5;
  return 0;
}
function nativeImmersionAvailable() {
  return Boolean(nativeHeadphoneSplitter && nativeHeadphoneMerger);
}
function applyNativeHeadphoneSettings(now: number, enabled: boolean) {
  const proof = state.dspVerificationMode === "spatial" && state.outputProfile === "headphones" && !state.dspBypass;
  const width = enabled ? (proof ? 1 : state.headphoneWidth / 100) : 0;
  const depth = enabled ? (proof ? 1 : state.headphoneDepth / 100) : 0;
  const crossfeed = enabled ? (proof ? 0.58 : state.headphoneCrossfeed / 100) : 0;
  const center = enabled ? (proof ? 0.5 : state.headphoneCenter / 100) : 0.5;
  const bass = enabled ? (proof ? 0 : state.headphoneBassImpact / 100) : 0;

  const widthScale = enabled ? (proof ? 2.65 : 1 + width * 1.35) : 1;
  const compensation = 1 / Math.max(1, 1 + Math.max(0, widthScale - 1) * 0.28 + depth * 0.16);
  const direct = ((1 + widthScale) / 2) * compensation;
  const widthCross = ((1 - widthScale) / 2) * compensation;
  const crossMix = enabled ? (proof ? 0.62 : crossfeed * 0.50) : 0;
  const crossDelay = enabled ? (proof ? 0.0014 : 0.00028 + crossfeed * 0.00095) : 0.00022;
  const depthMix = enabled ? (proof ? 0.58 : depth * 0.42) : 0;
  const depthDelay = enabled ? (proof ? 0.016 : 0.003 + depth * 0.0135) : 0.0018;
  const centerGain = enabled ? Math.max(-0.14, Math.min(0.52, (center - 0.5) * 0.96)) : 0;
  const bassDb = enabled ? bass * 4.5 : 0;

  if (nativeHeadphoneLeftDirect) setAudioParam(nativeHeadphoneLeftDirect.gain, direct, now);
  if (nativeHeadphoneRightDirect) setAudioParam(nativeHeadphoneRightDirect.gain, direct, now);
  if (nativeHeadphoneLeftWidthCross) setAudioParam(nativeHeadphoneLeftWidthCross.gain, widthCross, now);
  if (nativeHeadphoneRightWidthCross) setAudioParam(nativeHeadphoneRightWidthCross.gain, widthCross, now);
  if (nativeHeadphoneLeftCrossDelay) setAudioParam(nativeHeadphoneLeftCrossDelay.delayTime, crossDelay, now);
  if (nativeHeadphoneRightCrossDelay) setAudioParam(nativeHeadphoneRightCrossDelay.delayTime, crossDelay, now);
  if (nativeHeadphoneLeftCrossGain) setAudioParam(nativeHeadphoneLeftCrossGain.gain, crossMix, now);
  if (nativeHeadphoneRightCrossGain) setAudioParam(nativeHeadphoneRightCrossGain.gain, crossMix, now);
  if (nativeHeadphoneLeftDepthDelay) setAudioParam(nativeHeadphoneLeftDepthDelay.delayTime, depthDelay, now);
  if (nativeHeadphoneRightDepthDelay) setAudioParam(nativeHeadphoneRightDepthDelay.delayTime, depthDelay * 0.83, now);
  if (nativeHeadphoneLeftDepthGain) setAudioParam(nativeHeadphoneLeftDepthGain.gain, depthMix, now);
  if (nativeHeadphoneRightDepthGain) setAudioParam(nativeHeadphoneRightDepthGain.gain, depthMix, now);
  if (nativeHeadphoneCenterLeft) setAudioParam(nativeHeadphoneCenterLeft.gain, centerGain, now);
  if (nativeHeadphoneCenterRight) setAudioParam(nativeHeadphoneCenterRight.gain, centerGain, now);
  if (nativeHeadphoneBassShelf) setAudioParam(nativeHeadphoneBassShelf.gain, bassDb, now, 0.035);
}
function applyHeadphoneSettings(now: number) {
  const enabled =
    !state.dspBypass &&
    state.outputProfile === "headphones" &&
    (state.headphoneMode !== "off" || state.dspVerificationMode === "spatial");
  const proof = state.dspVerificationMode === "spatial" && state.outputProfile === "headphones" && !state.dspBypass;
  const values: Array<[string, number]> = [
    ["enabled", enabled ? 1 : 0],
    ["mode", enabled ? headphoneModeCode(state.headphoneMode) : 0],
    ["proof", proof ? 1 : 0],
    ["width", enabled ? (proof ? 1 : state.headphoneWidth / 100) : 0],
    ["depth", enabled ? (proof ? 1 : state.headphoneDepth / 100) : 0],
    ["crossfeed", enabled ? (proof ? 0.72 : state.headphoneCrossfeed / 100) : 0],
    ["center", enabled ? (proof ? 0.5 : state.headphoneCenter / 100) : 0.5],
    ["bassImpact", enabled ? (proof ? 0 : state.headphoneBassImpact / 100) : 0],
  ];
  values.forEach(([name, value]) => {
    const param = workletParam(headphoneProcessorNode, name);
    if (param) setAudioParam(param, value, now, 0.02);
  });
  if (!headphoneProcessorNode) applyNativeHeadphoneSettings(now, enabled);
}
function studioHrtfRequested() {
  const proof = state.dspVerificationMode === "spatial" && state.outputProfile === "headphones" && !state.dspBypass;
  return state.dspEngineMode === "studio_wasm" && !state.dspBypass && state.outputProfile === "headphones" && (state.headphoneMode !== "off" || proof);
}
function configureStudioHrtf(now: number) {
  if (!audioContext || !studioDirectInputGain || !studioHrtfInputGain) return;
  const active = studioHrtfRequested() && Boolean(studioHrtfLeftPanner && studioHrtfRightPanner && studioHrtfBassShelf);
  setAudioParam(studioDirectInputGain.gain, active ? 0 : 1, now, 0.018);
  setAudioParam(studioHrtfInputGain.gain, active ? 0.86 : 0, now, 0.018);
  if (!active || !studioHrtfLeftPanner || !studioHrtfRightPanner || !studioHrtfBassShelf) {
    if (studioHrtfReflectionGainA) setAudioParam(studioHrtfReflectionGainA.gain, 0, now, 0.025);
    if (studioHrtfReflectionGainB) setAudioParam(studioHrtfReflectionGainB.gain, 0, now, 0.025);
    return;
  }

  const proof = state.dspVerificationMode === "spatial";
  const width = proof ? 1 : Math.max(0, Math.min(1, state.headphoneWidth / 100));
  const depth = proof ? 1 : Math.max(0, Math.min(1, state.headphoneDepth / 100));
  const crossfeed = proof ? 0.55 : Math.max(0, Math.min(1, state.headphoneCrossfeed / 100));
  const center = proof ? 0.5 : Math.max(0, Math.min(1, state.headphoneCenter / 100));
  const bass = proof ? 0 : Math.max(0, Math.min(1, state.headphoneBassImpact / 100));

  const mode = state.headphoneMode;
  const baseAngle = mode === "wide" ? 38 : mode === "spatial" ? 34 : mode === "stage" ? 28 : mode === "focus" ? 17 : 27;
  const widthSpan = mode === "wide" ? 24 : mode === "spatial" ? 22 : mode === "stage" ? 16 : mode === "focus" ? 6 : 12;
  const centerPull = Math.max(0, center - 0.5) * 13;
  const crossfeedPull = crossfeed * 7;
  const angleDeg = Math.max(12, Math.min(62, baseAngle + width * widthSpan - centerPull - crossfeedPull));
  const angle = angleDeg * Math.PI / 180;
  const depthScale = mode === "spatial" ? 1.65 : mode === "stage" ? 1.15 : mode === "wide" ? 0.45 : mode === "focus" ? 0.25 : 0.55;
  const distance = 1.0 + depth * depthScale;
  const x = Math.sin(angle) * distance;
  const z = -Math.cos(angle) * distance;

  setAudioParam(studioHrtfLeftPanner.positionX, -x, now, 0.045);
  setAudioParam(studioHrtfLeftPanner.positionY, 0, now, 0.045);
  setAudioParam(studioHrtfLeftPanner.positionZ, z, now, 0.045);
  setAudioParam(studioHrtfRightPanner.positionX, x, now, 0.045);
  setAudioParam(studioHrtfRightPanner.positionY, 0, now, 0.045);
  setAudioParam(studioHrtfRightPanner.positionZ, z, now, 0.045);
  setAudioParam(studioHrtfBassShelf.gain, bass * (mode === "bass_impact" ? 5.2 : 3.2), now, 0.05);

  const reflectionAmount = depth * (mode === "spatial" ? 0.13 : mode === "stage" ? 0.09 : 0.045);
  if (studioHrtfReflectionDelayA) setAudioParam(studioHrtfReflectionDelayA.delayTime, 0.009 + depth * 0.009, now, 0.05);
  if (studioHrtfReflectionDelayB) setAudioParam(studioHrtfReflectionDelayB.delayTime, 0.015 + depth * 0.014, now, 0.05);
  if (studioHrtfReflectionGainA) setAudioParam(studioHrtfReflectionGainA.gain, reflectionAmount, now, 0.05);
  if (studioHrtfReflectionGainB) setAudioParam(studioHrtfReflectionGainB.gain, reflectionAmount * 0.62, now, 0.05);
}

function currentImmersionStatus(): MusicImmersionStatus {
  if (state.outputProfile !== "headphones" || state.dspBypass) return "bypassed";
  const requested = state.headphoneMode !== "off" || state.dspVerificationMode === "spatial";
  if (!requested) return "bypassed";
  if (studioHrtfRequested() && studioHrtfLeftPanner && studioHrtfRightPanner) return "active";
  if (studioProcessorNode && state.dspEngineMode === "studio_wasm") return "active";
  if (headphoneProcessorNode) return "active";
  if (nativeImmersionAvailable()) return "native_fallback";
  return "unavailable";
}
function sourceTransientScale() {
  const track = state.currentTrack;
  if (!track) return 1;
  const mime = (track.mime_type || "").toLowerCase();
  const name = (track.original_name || "").toLowerCase();
  if (mime.includes("wav") || name.endsWith(".wav") || mime.includes("flac") || name.endsWith(".flac")) return 0.72;
  const bytes = Number(track.file_size_bytes || 0);
  const seconds = Number(track.duration_seconds || 0);
  if (bytes > 0 && seconds > 0) {
    const kbps = (bytes * 8) / seconds / 1000;
    if (kbps < 192) return 1.12;
    if (kbps < 256) return 1.0;
    return 0.88;
  }
  return 0.92;
}
function applyTransientSettings(now: number, active: boolean) {
  if (!transientProcessorNode) return;
  const enabled = workletParam(transientProcessorNode, "enabled");
  const amount = workletParam(transientProcessorNode, "amount");
  const presetAmount = currentTransientAmount();
  if (enabled) setAudioParam(enabled, active && presetAmount > 0.001 ? 1 : 0, now, 0.02);
  if (amount) setAudioParam(amount, Math.max(0, Math.min(1, presetAmount * sourceTransientScale())), now, 0.035);
}

function applyMultibandSettings(now: number, active: boolean) {
  if (!multibandProcessorNode) return;
  const enabled = workletParam(multibandProcessorNode, "enabled");
  const amount = workletParam(multibandProcessorNode, "amount");
  const profileAmount =
    state.outputProfile === "speaker" ? 0.44 :
    state.outputProfile === "car_hifi" ? 0.36 :
    state.outputProfile === "headphones" ? 0.30 :
    0.28;
  if (enabled) setAudioParam(enabled, active && state.multibandEnabled ? 1 : 0, now, 0.02);
  if (amount) setAudioParam(amount, profileAmount, now, 0.06);
}

function applyLoudnessNormalizationSettings(now: number, active: boolean) {
  if (!loudnessNormalizerNode) return;
  const enabled = workletParam(loudnessNormalizerNode, "enabled");
  const target = workletParam(loudnessNormalizerNode, "targetLufs");
  if (enabled) setAudioParam(enabled, active && state.normalizationEnabled ? 1 : 0, now, 0.03);
  if (target) setAudioParam(target, -10, now, 0.12);
}

function applyLimiterSettings(now: number, limiterActive: boolean) {
  if (limiterWorkletNode) {
    const enabled = workletParam(limiterWorkletNode, "enabled");
    const ceiling = workletParam(limiterWorkletNode, "ceilingDb");
    const release = workletParam(limiterWorkletNode, "releaseMs");
    if (enabled) setAudioParam(enabled, limiterActive ? 1 : 0, now, 0.01);
    if (ceiling) setAudioParam(ceiling, state.outputProfile === "car_hifi" ? -1.2 : state.outputProfile === "speaker" ? -1.15 : -1.0, now, 0.02);
    if (release) setAudioParam(release, state.outputProfile === "speaker" ? 125 : state.outputProfile === "car_hifi" ? 88 : 98, now, 0.03);
  }
  if (limiterFallbackNode) {
    if (limiterActive) {
      limiterFallbackNode.threshold.value = -0.9;
      limiterFallbackNode.knee.value = 0;
      limiterFallbackNode.ratio.value = 20;
      limiterFallbackNode.attack.value = 0.0015;
      limiterFallbackNode.release.value = 0.11;
    } else {
      setCompressorBypass(limiterFallbackNode);
    }
  }
}
function applyProcessingSettings() {
  if (!audioContext || !mediaSourceConnected) return;
  const now = audioContext.currentTime;
  if (studioProcessorNode && state.dspEngineMode === "studio_wasm") {
    applyStudioProcessingSettings(now);
    return;
  }
  configureProfessionalFilters(now);
  configureGraphicEq(now);
  configureOutputFilters(now);
  const { effectivePreampDb, autoHeadroomDb, makeupDb, referenceMatchDb } = calculateProcessingGain();
  const pureReference = state.outputProfile === "reference";
  const abBypass = !pureReference && state.dspBypass;
  const processed = !pureReference && !abBypass;
  const headphones = processed && state.outputProfile === "headphones" && Boolean(headphoneProcessorNode || nativeImmersionAvailable());
  const standard = processed && !headphones;

  if (masterVolumeGain) setAudioParam(masterVolumeGain.gain, volumeToGain(state.volume), now, 0.01);
  if (referenceRouteGain) {
    const referenceGain = pureReference ? 1 : abBypass ? dbToGain(referenceMatchDb) : 0;
    setAudioParam(referenceRouteGain.gain, referenceGain, now, 0.008);
  }
  if (standardRouteGain) setAudioParam(standardRouteGain.gain, standard ? 1 : 0, now, 0.008);
  if (headphoneRouteGain) setAudioParam(headphoneRouteGain.gain, headphones ? 1 : 0, now, 0.008);
  if (preampGain) setAudioParam(preampGain.gain, dbToGain(effectivePreampDb), now, 0.018);
  if (makeupGain) setAudioParam(makeupGain.gain, dbToGain(pureReference ? 0 : makeupDb), now, 0.025);

  applyTransientSettings(now, processed);
  applyMultibandSettings(now, processed);
  applyLoudnessNormalizationSettings(now, processed);
  applyHeadphoneSettings(now);
  applyLimiterSettings(now, !pureReference && state.limiterEnabled);

  const status: MusicDspStatus =
    audioContext.state === "running" ? (pureReference || abBypass ? "bypassed" : "active") : "recovering";
  setDspTelemetry(status, effectivePreampDb, autoHeadroomDb);
  const immersionStatus = currentImmersionStatus();
  if (state.immersionStatus !== immersionStatus) emit({ immersionStatus });
}
function disconnectNode(node: AudioNode | null) {
  if (!node) return;
  try {
    node.disconnect();
  } catch {
    /* already disconnected */
  }
}
function releaseGraph() {
  clearTransitionPreload();
  [
    mediaSource,
    masterVolumeGain,
    referenceRouteGain,
    preampGain,
    studioProcessorNode,
    transientProcessorNode,
    loudnessNormalizerNode,
    multibandProcessorNode,
    professionalHighpass,
    professionalLowShelf,
    professionalHighShelf,
    outputHighpass,
    outputLowShelf,
    outputPresence,
    outputClarity,
    outputHighShelf,
    standardRouteGain,
    studioDirectInputGain,
    studioHrtfSplitter,
    studioHrtfLeftPanner,
    studioHrtfRightPanner,
    studioHrtfSum,
    studioHrtfBassShelf,
    studioHrtfReflectionDelayA,
    studioHrtfReflectionDelayB,
    studioHrtfReflectionGainA,
    studioHrtfReflectionGainB,
    studioHrtfInputGain,
    studioInputBus,
    headphoneProcessorNode,
    nativeHeadphoneBassShelf,
    nativeHeadphoneSplitter,
    nativeHeadphoneMerger,
    nativeHeadphoneLeftDirect,
    nativeHeadphoneRightDirect,
    nativeHeadphoneLeftWidthCross,
    nativeHeadphoneRightWidthCross,
    nativeHeadphoneLeftCrossDelay,
    nativeHeadphoneRightCrossDelay,
    nativeHeadphoneLeftCrossLowpass,
    nativeHeadphoneRightCrossLowpass,
    nativeHeadphoneLeftCrossGain,
    nativeHeadphoneRightCrossGain,
    nativeHeadphoneLeftDepthDelay,
    nativeHeadphoneRightDepthDelay,
    nativeHeadphoneLeftDepthGain,
    nativeHeadphoneRightDepthGain,
    nativeHeadphoneCenterSum,
    nativeHeadphoneCenterLeft,
    nativeHeadphoneCenterRight,
    headphoneRouteGain,
    mixBus,
    makeupGain,
    limiterWorkletNode,
    limiterFallbackNode,
    analyserNode,
    referenceLevelAnalyser,
    processedLevelAnalyser,
    levelMeterSink,
    musicGain,
  ].forEach(disconnectNode);
  professionalPeakFilters.forEach(disconnectNode);
  equalizerFilters.forEach(disconnectNode);
  mediaSource = null;
  masterVolumeGain = null;
  referenceRouteGain = null;
  preampGain = null;
  try { studioProcessorNode?.port.close(); } catch { /* already closed */ }
  studioProcessorNode = null;
  transientProcessorNode = null;
  loudnessNormalizerNode = null;
  multibandProcessorNode = null;
  professionalHighpass = null;
  professionalLowShelf = null;
  professionalPeakFilters = [];
  professionalHighShelf = null;
  equalizerFilters = [];
  linearPhaseEqNode = null;
  outputHighpass = null;
  outputLowShelf = null;
  outputPresence = null;
  outputClarity = null;
  outputHighShelf = null;
  standardRouteGain = null;
  studioDirectInputGain = null;
  studioHrtfSplitter = null;
  studioHrtfLeftPanner = null;
  studioHrtfRightPanner = null;
  studioHrtfSum = null;
  studioHrtfBassShelf = null;
  studioHrtfReflectionDelayA = null;
  studioHrtfReflectionDelayB = null;
  studioHrtfReflectionGainA = null;
  studioHrtfReflectionGainB = null;
  studioHrtfInputGain = null;
  studioInputBus = null;
  headphoneProcessorNode = null;
  nativeHeadphoneBassShelf = null;
  nativeHeadphoneSplitter = null;
  nativeHeadphoneMerger = null;
  nativeHeadphoneLeftDirect = null;
  nativeHeadphoneRightDirect = null;
  nativeHeadphoneLeftWidthCross = null;
  nativeHeadphoneRightWidthCross = null;
  nativeHeadphoneLeftCrossDelay = null;
  nativeHeadphoneRightCrossDelay = null;
  nativeHeadphoneLeftCrossLowpass = null;
  nativeHeadphoneRightCrossLowpass = null;
  nativeHeadphoneLeftCrossGain = null;
  nativeHeadphoneRightCrossGain = null;
  nativeHeadphoneLeftDepthDelay = null;
  nativeHeadphoneRightDepthDelay = null;
  nativeHeadphoneLeftDepthGain = null;
  nativeHeadphoneRightDepthGain = null;
  nativeHeadphoneCenterSum = null;
  nativeHeadphoneCenterLeft = null;
  nativeHeadphoneCenterRight = null;
  headphoneRouteGain = null;
  mixBus = null;
  makeupGain = null;
  limiterWorkletNode = null;
  limiterFallbackNode = null;
  analyserNode = null;
  referenceLevelAnalyser = null;
  processedLevelAnalyser = null;
  levelMeterSink = null;
  musicGain = null;
  analyserBuffer = null;
  if (levelMeterTimer && typeof window !== "undefined") window.clearInterval(levelMeterTimer);
  levelMeterTimer = 0;
  lastReferenceRmsDb = Number.NaN;
  lastProcessedRmsDb = Number.NaN;
  mediaSourceConnected = false;
  graphBuildPromise = null;
  if (state.dspEngineMode !== "unavailable" || state.immersionStatus !== "bypassed") {
    emit({ dspEngineMode: "unavailable", immersionStatus: "bypassed" });
  }
}

function studioOutputProfileCode(): 0 | 1 | 2 {
  if (state.outputProfile === "headphones") return 1;
  if (state.outputProfile === "speaker") return 2;
  return 0;
}
function calculateStudioGain() {
  // MVP_STUDIO_WASM_V1_1_GAIN_STAGING_FIX
  // EQ bands are tonal controls, not a global-volume control. Studio V1 previously
  // derived auto headroom from the largest positive band and then subtracted that
  // value from the entire signal. V1.1 keeps user/preset preamp independent from
  // EQ-band movement and lets the WASM output limiter handle real peak events.
  if (state.outputProfile === "reference") {
    return { effectivePreampDb: 0, autoHeadroomDb: 0, referenceMatchDb: 0 };
  }
  const requested = state.eqEnabled
    ? Math.max(-12, Math.min(6, Number(state.preampDb) || 0))
    : 0;
  const autoHeadroomDb = 0;
  const effectivePreampDb = requested;
  const measuredMatch = Number.isFinite(lastReferenceRmsDb) && Number.isFinite(lastProcessedRmsDb)
    ? Math.max(-6, Math.min(3, lastProcessedRmsDb - lastReferenceRmsDb))
    : Math.max(-6, Math.min(3, effectivePreampDb));
  return { effectivePreampDb, autoHeadroomDb, referenceMatchDb: measuredMatch };
}
function applyStudioProcessingSettings(now: number) {
  if (!audioContext || !studioProcessorNode) return;
  const { effectivePreampDb, autoHeadroomDb, referenceMatchDb } = calculateStudioGain();
  const pureReference = state.outputProfile === "reference";
  const abBypass = !pureReference && state.dspBypass;
  const processed = !pureReference && !abBypass;
  if (masterVolumeGain) setAudioParam(masterVolumeGain.gain, volumeToGain(state.volume), now, 0.01);
  if (referenceRouteGain) {
    setAudioParam(referenceRouteGain.gain, pureReference ? 1 : abBypass ? dbToGain(referenceMatchDb) : 0, now, 0.008);
  }
  if (standardRouteGain) setAudioParam(standardRouteGain.gain, processed ? 1 : 0, now, 0.008);
  configureStudioHrtf(now);
  const proof = state.dspVerificationMode === "spatial" && state.outputProfile === "headphones" && !state.dspBypass;
  const headphoneEnabled = false; // Studio path uses the browser's measured-IR HRTF virtual loudspeaker renderer before WASM.
  // MVP_STUDIO_WASM_V2_TRANSIENT
  // The same preset/source-aware transient amount used by the Compatibility engine
  // now drives a stereo-linked shaper inside the WASM core. It never changes EQ
  // headroom or preamp, so the V1.1 gain-staging fix remains intact.
  const studioPersonality = currentStudioPersonality();
  const studioTransientAmount = processed && state.eqEnabled
    ? Math.max(0, Math.min(1, currentTransientAmount() * sourceTransientScale() * studioPersonality.transientScale))
    : 0;
  setMvpStudioState(studioProcessorNode, {
    bypass: !processed,
    eqEnabled: processed && state.eqEnabled,
    // MVP_STUDIO_WASM_V3_PHASE3_LINEAR_PHASE
    // Both EQ topologies now run inside the same Studio WASM processor.
    eqTopologyCode: state.eqTopology === "linear_phase" ? 1 : 0,
    eqGains: [...state.eqGains],
    preampDb: state.eqEnabled ? state.preampDb : 0,
    headroomDb: autoHeadroomDb,
    transientEnabled: studioTransientAmount > 0.001,
    transientAmount: studioTransientAmount,
    // MVP_STUDIO_WASM_V2_PHASE2_MULTIBAND
    multibandEnabled: processed && state.multibandEnabled,
    multibandAmount: studioPersonality.multibandAmount,
    // MVP_STUDIO_WASM_V3_PHASE1_DYNAMIC_EQ
    // Cut-only adaptive resonance control. It never adds makeup gain and therefore
    // cannot reintroduce the old EQ-slider/global-volume bug.
    dynamicEqEnabled: processed && state.dynamicEqEnabled,
    dynamicEqAmount: studioPersonality.dynamicEqAmount,
    // MVP_STUDIO_WASM_V3_PHASE2_OUTPUT_CORRECTION
    // Device-path intelligence stays separate from the musical preset. The WASM
    // core chooses the correct adaptive guard behavior from outputProfileCode.
    outputCorrectionEnabled: processed,
    outputCorrectionAmount: studioPersonality.outputCorrectionAmount,
    // MVP_STUDIO_WASM_V3_PHASE6_STEREO_INTEGRITY
    // Automatic mono-compatible low bass and anti-phase image protection.
    stereoIntegrityEnabled: processed,
    stereoIntegrityAmount: studioPersonality.stereoIntegrityAmount,
    // MVP_STUDIO_WASM_V2_PHASE3_LOUDNESS
    // MVP_STUDIO_WASM_V2_PHASE3_1_VOLUME_MATCH
    normalizationEnabled: processed && state.normalizationEnabled,
    normalizationTargetLufs: -10,
    // MVP_STUDIO_WASM_V3_PHASE4_TRUE_PEAK_LIMITER
    // BS.1770-style 4x FIR true-peak detection drives the Studio limiter.
    limiterEnabled: processed && state.limiterEnabled,
    limiterCeilingDb: state.outputProfile === "car_hifi" ? -1.2 : state.outputProfile === "speaker" ? -1.15 : -1.0,
    outputProfileCode: studioOutputProfileCode(),
    headphoneEnabled,
    headphoneWidth: headphoneEnabled ? (proof ? 1 : state.headphoneWidth / 100) : 0,
    headphoneDepth: headphoneEnabled ? (proof ? 1 : state.headphoneDepth / 100) : 0,
    headphoneCrossfeed: headphoneEnabled ? (proof ? 0.72 : state.headphoneCrossfeed / 100) : 0,
    headphoneCenter: headphoneEnabled ? (proof ? 0.5 : state.headphoneCenter / 100) : 0.5,
    headphoneBassImpact: headphoneEnabled ? (proof ? 0 : state.headphoneBassImpact / 100) : 0,
  });
  const runtime = getMvpStudioRuntimeInfo();
  const stateVerified = runtime.ready && !runtime.faulted && runtime.requestedRevision <= runtime.appliedRevision;
  const status: MusicDspStatus = audioContext.state === "running"
    ? (pureReference || abBypass ? "bypassed" : stateVerified ? "active" : "recovering")
    : "recovering";
  setDspTelemetry(status, effectivePreampDb, autoHeadroomDb);
  const immersionStatus = currentImmersionStatus();
  if (state.immersionStatus !== immersionStatus) emit({ immersionStatus });
}
async function tryConnectStudioGraph(context: AudioContext, audio: HTMLAudioElement) {
  // V3 Phase 3: Minimum Phase and Linear Phase are both flagship Studio WASM modes.
  if (!context.audioWorklet) return false;
  let sourceCreated = false;
  try {
    studioProcessorNode = await createMvpStudioNode(context);
  } catch (error) {
    studioProcessorNode = null;
    console.warn("MVP Studio WASM unavailable; trying Compatibility Engine.", error);
    return false;
  }
  try {
    mediaSource = context.createMediaElementSource(audio);
    sourceCreated = true;
    masterVolumeGain = context.createGain();
    referenceRouteGain = context.createGain();
    referenceRouteGain.gain.value = 0;
    standardRouteGain = context.createGain();
    standardRouteGain.gain.value = 0;
    studioInputBus = context.createGain();
    studioDirectInputGain = context.createGain();
    studioDirectInputGain.gain.value = 1;
    studioHrtfInputGain = context.createGain();
    studioHrtfInputGain.gain.value = 0;
    studioHrtfSplitter = context.createChannelSplitter(2);
    studioHrtfLeftPanner = context.createPanner();
    studioHrtfRightPanner = context.createPanner();
    for (const panner of [studioHrtfLeftPanner, studioHrtfRightPanner]) {
      panner.panningModel = "HRTF";
      panner.distanceModel = "inverse";
      panner.refDistance = 1;
      panner.maxDistance = 10000;
      panner.rolloffFactor = 0.12;
    }
    studioHrtfSum = context.createGain();
    studioHrtfSum.gain.value = 1;
    studioHrtfBassShelf = context.createBiquadFilter();
    studioHrtfBassShelf.type = "lowshelf";
    studioHrtfBassShelf.frequency.value = 92;
    studioHrtfBassShelf.gain.value = 0;
    studioHrtfReflectionDelayA = context.createDelay(0.06);
    studioHrtfReflectionDelayB = context.createDelay(0.06);
    studioHrtfReflectionGainA = context.createGain();
    studioHrtfReflectionGainB = context.createGain();
    studioHrtfReflectionGainA.gain.value = 0;
    studioHrtfReflectionGainB.gain.value = 0;
    mixBus = context.createGain();
    analyserNode = context.createAnalyser();
    analyserNode.fftSize = 4096;
    analyserNode.smoothingTimeConstant = 0.38;
    analyserNode.minDecibels = -92;
    analyserNode.maxDecibels = -10;
    musicGain = context.createGain();
    musicGain.gain.value = 1;
    referenceLevelAnalyser = context.createAnalyser();
    processedLevelAnalyser = context.createAnalyser();
    referenceLevelAnalyser.fftSize = 2048;
    processedLevelAnalyser.fftSize = 2048;
    levelMeterSink = context.createGain();
    levelMeterSink.gain.value = 0;

    mediaSource.connect(masterVolumeGain);
    masterVolumeGain.connect(referenceRouteGain);
    referenceRouteGain.connect(mixBus);

    // Direct processed path.
    masterVolumeGain.connect(studioDirectInputGain);
    studioDirectInputGain.connect(studioInputBus);

    // Headphones: split the stereo master into two mono virtual loudspeakers and
    // let the browser HRTF renderer convolve each source with measured head-related
    // impulse responses. The resulting binaural stereo is then mastered/limited by WASM.
    masterVolumeGain.connect(studioHrtfSplitter);
    studioHrtfSplitter.connect(studioHrtfLeftPanner, 0);
    studioHrtfSplitter.connect(studioHrtfRightPanner, 1);
    studioHrtfLeftPanner.connect(studioHrtfSum);
    studioHrtfRightPanner.connect(studioHrtfSum);
    studioHrtfSum.connect(studioHrtfBassShelf);
    studioHrtfBassShelf.connect(studioHrtfInputGain);
    studioHrtfInputGain.connect(studioInputBus);
    studioHrtfBassShelf.connect(studioHrtfReflectionDelayA);
    studioHrtfBassShelf.connect(studioHrtfReflectionDelayB);
    studioHrtfReflectionDelayA.connect(studioHrtfReflectionGainA);
    studioHrtfReflectionDelayB.connect(studioHrtfReflectionGainB);
    studioHrtfReflectionGainA.connect(studioInputBus);
    studioHrtfReflectionGainB.connect(studioInputBus);

    studioInputBus.connect(studioProcessorNode);
    studioProcessorNode.connect(standardRouteGain);
    standardRouteGain.connect(mixBus);
    mixBus.connect(analyserNode);
    analyserNode.connect(musicGain);
    musicGain.connect(context.destination);

    masterVolumeGain.connect(referenceLevelAnalyser);
    referenceLevelAnalyser.connect(levelMeterSink);
    studioProcessorNode.connect(processedLevelAnalyser);
    processedLevelAnalyser.connect(levelMeterSink);
    levelMeterSink.connect(context.destination);

    mediaSourceConnected = true;
    audio.volume = 1;
    emit({
      dspEngineMode: "studio_wasm",
      loudnessGainDb: 0,
      loudnessMomentaryLufs: -70,
      truePeakDbtp: -120,
      limiterGainReductionDb: 0,
      transientBoostDb: 0,
      multibandGainReductionDb: 0,
      stereoCorrelation: 1,
      stereoWidthPercent: 100,
      stereoGuardReductionDb: 0,
    });
    applyProcessingSettings();
    return true;
  } catch (error) {
    if (sourceCreated) throw error;
    try { studioProcessorNode?.disconnect(); } catch { /* no-op */ }
    studioProcessorNode = null;
    return false;
  }
}
async function loadAdvancedDspModule(context: AudioContext) {
  if (!context.audioWorklet) return false;
  try {
    const moduleUrl = new URL("./audio/mvpMusicDsp.worklet.js", import.meta.url);
    moduleUrl.searchParams.set("v", "13.9.14");
    await context.audioWorklet.addModule(moduleUrl.href);
    return true;
  } catch (error) {
    console.warn("Advanced music DSP worklet unavailable; using native Web Audio fallback.", error);
    return false;
  }
}
function createProfessionalFilterBank(context: AudioContext) {
  professionalHighpass = context.createBiquadFilter();
  professionalHighpass.type = "highpass";
  professionalLowShelf = context.createBiquadFilter();
  professionalLowShelf.type = "lowshelf";
  professionalPeakFilters = Array.from({ length: PRO_PEAK_COUNT }, () => {
    const filter = context.createBiquadFilter();
    filter.type = "peaking";
    filter.Q.value = 1;
    filter.gain.value = 0;
    return filter;
  });
  professionalHighShelf = context.createBiquadFilter();
  professionalHighShelf.type = "highshelf";
}
function createGraphicEq(context: AudioContext) {
  equalizerFilters = MUSIC_EQ_FREQUENCIES.map((frequency) => {
    const filter = context.createBiquadFilter();
    filter.type = "peaking";
    filter.frequency.value = clampFilterFrequency(context, frequency);
    filter.Q.value = GRAPHIC_EQ_Q;
    filter.gain.value = 0;
    return filter;
  });
}
function createOutputFilterBank(context: AudioContext) {
  outputHighpass = context.createBiquadFilter();
  outputHighpass.type = "highpass";
  outputLowShelf = context.createBiquadFilter();
  outputLowShelf.type = "lowshelf";
  outputPresence = context.createBiquadFilter();
  outputPresence.type = "peaking";
  outputClarity = context.createBiquadFilter();
  outputClarity.type = "peaking";
  outputHighShelf = context.createBiquadFilter();
  outputHighShelf.type = "highshelf";
}
function createNativeHeadphoneFallback(context: AudioContext) {
  nativeHeadphoneBassShelf = context.createBiquadFilter();
  nativeHeadphoneBassShelf.type = "lowshelf";
  nativeHeadphoneBassShelf.frequency.value = 105;
  nativeHeadphoneSplitter = context.createChannelSplitter(2);
  nativeHeadphoneMerger = context.createChannelMerger(2);
  nativeHeadphoneLeftDirect = context.createGain();
  nativeHeadphoneRightDirect = context.createGain();
  nativeHeadphoneLeftDirect.gain.value = 1;
  nativeHeadphoneRightDirect.gain.value = 1;
  nativeHeadphoneLeftWidthCross = context.createGain();
  nativeHeadphoneRightWidthCross = context.createGain();
  nativeHeadphoneLeftWidthCross.gain.value = 0;
  nativeHeadphoneRightWidthCross.gain.value = 0;
  nativeHeadphoneLeftCrossDelay = context.createDelay(0.02);
  nativeHeadphoneRightCrossDelay = context.createDelay(0.02);
  nativeHeadphoneLeftCrossLowpass = context.createBiquadFilter();
  nativeHeadphoneRightCrossLowpass = context.createBiquadFilter();
  nativeHeadphoneLeftCrossLowpass.type = "lowpass";
  nativeHeadphoneRightCrossLowpass.type = "lowpass";
  nativeHeadphoneLeftCrossLowpass.frequency.value = 1250;
  nativeHeadphoneRightCrossLowpass.frequency.value = 1250;
  nativeHeadphoneLeftCrossGain = context.createGain();
  nativeHeadphoneRightCrossGain = context.createGain();
  nativeHeadphoneLeftCrossGain.gain.value = 0;
  nativeHeadphoneRightCrossGain.gain.value = 0;
  nativeHeadphoneLeftDepthDelay = context.createDelay(0.02);
  nativeHeadphoneRightDepthDelay = context.createDelay(0.02);
  nativeHeadphoneLeftDepthGain = context.createGain();
  nativeHeadphoneRightDepthGain = context.createGain();
  nativeHeadphoneLeftDepthGain.gain.value = 0;
  nativeHeadphoneRightDepthGain.gain.value = 0;
  nativeHeadphoneCenterSum = context.createGain();
  nativeHeadphoneCenterSum.gain.value = 0.5;
  nativeHeadphoneCenterLeft = context.createGain();
  nativeHeadphoneCenterRight = context.createGain();
  nativeHeadphoneCenterLeft.gain.value = 0;
  nativeHeadphoneCenterRight.gain.value = 0;
}
function connectNativeHeadphoneFallback(source: AudioNode) {
  if (
    !nativeHeadphoneBassShelf || !nativeHeadphoneSplitter || !nativeHeadphoneMerger ||
    !nativeHeadphoneLeftDirect || !nativeHeadphoneRightDirect ||
    !nativeHeadphoneLeftWidthCross || !nativeHeadphoneRightWidthCross ||
    !nativeHeadphoneLeftCrossDelay || !nativeHeadphoneRightCrossDelay ||
    !nativeHeadphoneLeftCrossLowpass || !nativeHeadphoneRightCrossLowpass ||
    !nativeHeadphoneLeftCrossGain || !nativeHeadphoneRightCrossGain ||
    !nativeHeadphoneLeftDepthDelay || !nativeHeadphoneRightDepthDelay ||
    !nativeHeadphoneLeftDepthGain || !nativeHeadphoneRightDepthGain ||
    !nativeHeadphoneCenterSum || !nativeHeadphoneCenterLeft || !nativeHeadphoneCenterRight ||
    !headphoneRouteGain
  ) return;

  source.connect(nativeHeadphoneBassShelf);
  nativeHeadphoneBassShelf.connect(nativeHeadphoneSplitter);

  nativeHeadphoneSplitter.connect(nativeHeadphoneLeftDirect, 0);
  nativeHeadphoneLeftDirect.connect(nativeHeadphoneMerger, 0, 0);
  nativeHeadphoneSplitter.connect(nativeHeadphoneRightDirect, 1);
  nativeHeadphoneRightDirect.connect(nativeHeadphoneMerger, 0, 1);

  nativeHeadphoneSplitter.connect(nativeHeadphoneLeftWidthCross, 0);
  nativeHeadphoneLeftWidthCross.connect(nativeHeadphoneMerger, 0, 1);
  nativeHeadphoneSplitter.connect(nativeHeadphoneRightWidthCross, 1);
  nativeHeadphoneRightWidthCross.connect(nativeHeadphoneMerger, 0, 0);

  nativeHeadphoneSplitter.connect(nativeHeadphoneLeftCrossDelay, 0);
  nativeHeadphoneLeftCrossDelay.connect(nativeHeadphoneLeftCrossLowpass);
  nativeHeadphoneLeftCrossLowpass.connect(nativeHeadphoneLeftCrossGain);
  nativeHeadphoneLeftCrossGain.connect(nativeHeadphoneMerger, 0, 1);
  nativeHeadphoneSplitter.connect(nativeHeadphoneRightCrossDelay, 1);
  nativeHeadphoneRightCrossDelay.connect(nativeHeadphoneRightCrossLowpass);
  nativeHeadphoneRightCrossLowpass.connect(nativeHeadphoneRightCrossGain);
  nativeHeadphoneRightCrossGain.connect(nativeHeadphoneMerger, 0, 0);

  nativeHeadphoneSplitter.connect(nativeHeadphoneLeftDepthDelay, 0);
  nativeHeadphoneLeftDepthDelay.connect(nativeHeadphoneLeftDepthGain);
  nativeHeadphoneLeftDepthGain.connect(nativeHeadphoneMerger, 0, 1);
  nativeHeadphoneSplitter.connect(nativeHeadphoneRightDepthDelay, 1);
  nativeHeadphoneRightDepthDelay.connect(nativeHeadphoneRightDepthGain);
  nativeHeadphoneRightDepthGain.connect(nativeHeadphoneMerger, 0, 0);

  nativeHeadphoneSplitter.connect(nativeHeadphoneCenterSum, 0);
  nativeHeadphoneSplitter.connect(nativeHeadphoneCenterSum, 1);
  nativeHeadphoneCenterSum.connect(nativeHeadphoneCenterLeft);
  nativeHeadphoneCenterSum.connect(nativeHeadphoneCenterRight);
  nativeHeadphoneCenterLeft.connect(nativeHeadphoneMerger, 0, 0);
  nativeHeadphoneCenterRight.connect(nativeHeadphoneMerger, 0, 1);

  nativeHeadphoneMerger.connect(headphoneRouteGain);
}
async function connectMusicGraph() {
  if (mediaSourceConnected) return;
  if (graphBuildPromise) return graphBuildPromise;
  graphBuildPromise = (async () => {
    const audio = ensureAudioElement();
    const context = getAudioContext();
    if (!context || mediaSourceConnected) return;
    try {
      if (await tryConnectStudioGraph(context, audio)) return;
      const advancedDsp = await loadAdvancedDspModule(context);
      mediaSource = context.createMediaElementSource(audio);
      masterVolumeGain = context.createGain();
      referenceRouteGain = context.createGain();
      referenceRouteGain.gain.value = 0;
      preampGain = context.createGain();
      createProfessionalFilterBank(context);
      createGraphicEq(context);
      createOutputFilterBank(context);
      standardRouteGain = context.createGain();
      standardRouteGain.gain.value = 0;
      headphoneRouteGain = context.createGain();
      headphoneRouteGain.gain.value = 0;
      mixBus = context.createGain();
      makeupGain = context.createGain();
      analyserNode = context.createAnalyser();
      analyserNode.fftSize = 4096;
      analyserNode.smoothingTimeConstant = 0.38;
      analyserNode.minDecibels = -92;
      analyserNode.maxDecibels = -10;
      musicGain = context.createGain();
      musicGain.gain.value = 1;
      referenceLevelAnalyser = context.createAnalyser();
      processedLevelAnalyser = context.createAnalyser();
      referenceLevelAnalyser.fftSize = 2048;
      processedLevelAnalyser.fftSize = 2048;
      levelMeterSink = context.createGain();
      levelMeterSink.gain.value = 0;

      let engineMode: MusicDspEngineMode = "native_fallback";
      if (advancedDsp) {
        try {
          transientProcessorNode = new AudioWorkletNode(context, "mvp-transient-processor", { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2], channelCount: 2, channelCountMode: "max" });
          linearPhaseEqNode = new AudioWorkletNode(context, "mvp-linear-phase-eq", { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2], channelCount: 2, channelCountMode: "max" });
          multibandProcessorNode = new AudioWorkletNode(context, "mvp-multiband-processor", {
            numberOfInputs: 1,
            numberOfOutputs: 1,
            outputChannelCount: [2],
            channelCount: 2,
            channelCountMode: "max",
          });
          loudnessNormalizerNode = new AudioWorkletNode(context, "mvp-loudness-normalizer", {
            numberOfInputs: 2,
            numberOfOutputs: 1,
            outputChannelCount: [2],
            channelCount: 2,
            channelCountMode: "max",
          });
          loudnessNormalizerNode.port.onmessage = (event) => {
            const data = event.data;
            if (!data || data.type !== "telemetry") return;
            const gainDb = Number(data.gainDb);
            const lufs = Number(data.lufs);
            emit({
              loudnessGainDb: Number.isFinite(gainDb) ? Math.round(gainDb * 10) / 10 : 0,
              loudnessMomentaryLufs: Number.isFinite(lufs) ? Math.round(lufs * 10) / 10 : -70,
            });
          };
          headphoneProcessorNode = new AudioWorkletNode(context, "mvp-headphone-processor", {
            numberOfInputs: 1,
            numberOfOutputs: 1,
            outputChannelCount: [2],
            channelCount: 2,
            channelCountMode: "max",
          });
          limiterWorkletNode = new AudioWorkletNode(context, "mvp-lookahead-limiter", {
            numberOfInputs: 1,
            numberOfOutputs: 1,
            outputChannelCount: [2],
            channelCount: 2,
            channelCountMode: "max",
          });
          engineMode = "advanced_worklet";
        } catch (error) {
          console.warn("Advanced DSP nodes failed; using native fallback.", error);
          transientProcessorNode = null;
          linearPhaseEqNode = null;
          multibandProcessorNode = null;
          loudnessNormalizerNode = null;
          headphoneProcessorNode = null;
          limiterWorkletNode = null;
        }
      }
      if (engineMode === "native_fallback") {
        createNativeHeadphoneFallback(context);
        limiterFallbackNode = context.createDynamicsCompressor();
      }
      emit({ dspEngineMode: engineMode });

      mediaSource.connect(masterVolumeGain);
      masterVolumeGain.connect(referenceRouteGain);
      referenceRouteGain.connect(mixBus);

      if (loudnessNormalizerNode) {
        masterVolumeGain.connect(loudnessNormalizerNode, 0, 0);
        mediaSource.connect(loudnessNormalizerNode, 0, 1);
        loudnessNormalizerNode.connect(preampGain);
      } else {
        masterVolumeGain.connect(preampGain);
      }
      let processedTail: AudioNode = preampGain;
      if (transientProcessorNode) {
        processedTail.connect(transientProcessorNode);
        processedTail = transientProcessorNode;
      }
      const professionalNodes = [
        professionalHighpass,
        professionalLowShelf,
        ...professionalPeakFilters,
        professionalHighShelf,
      ].filter((node): node is BiquadFilterNode => Boolean(node));
      professionalNodes.forEach((node) => {
        processedTail.connect(node);
        processedTail = node;
      });
      equalizerFilters.forEach((filter) => {
        processedTail.connect(filter);
        processedTail = filter;
      });
      if (linearPhaseEqNode) {
        processedTail.connect(linearPhaseEqNode);
        processedTail = linearPhaseEqNode;
      }
      if (multibandProcessorNode) {
        processedTail.connect(multibandProcessorNode);
        processedTail = multibandProcessorNode;
      }
      const outputNodes = [outputHighpass, outputLowShelf, outputPresence, outputClarity, outputHighShelf].filter(
        (node): node is BiquadFilterNode => Boolean(node),
      );
      outputNodes.forEach((node) => {
        processedTail.connect(node);
        processedTail = node;
      });

      processedTail.connect(standardRouteGain);
      standardRouteGain.connect(mixBus);
      if (headphoneProcessorNode) {
        processedTail.connect(headphoneProcessorNode);
        headphoneProcessorNode.connect(headphoneRouteGain);
      } else if (nativeImmersionAvailable()) {
        connectNativeHeadphoneFallback(processedTail);
      }
      headphoneRouteGain.connect(mixBus);

      mixBus.connect(makeupGain);
      let limiterTail: AudioNode = makeupGain;
      if (limiterWorkletNode) {
        limiterTail.connect(limiterWorkletNode);
        limiterTail = limiterWorkletNode;
      } else if (limiterFallbackNode) {
        limiterTail.connect(limiterFallbackNode);
        limiterTail = limiterFallbackNode;
      }
      limiterTail.connect(analyserNode);
      analyserNode.connect(musicGain);
      musicGain.connect(context.destination);
      if (referenceLevelAnalyser && processedLevelAnalyser && levelMeterSink) {
        masterVolumeGain.connect(referenceLevelAnalyser);
        referenceLevelAnalyser.connect(levelMeterSink);
        makeupGain.connect(processedLevelAnalyser);
        processedLevelAnalyser.connect(levelMeterSink);
        levelMeterSink.connect(context.destination);
      }

      mediaSourceConnected = true;
      audio.volume = 1;
      applyProcessingSettings();
    } catch (error) {
      console.warn("Music Pro DSP graph unavailable; browser will use direct audio output.", error);
      releaseGraph();
      emit({ dspStatus: "unavailable", dspEngineMode: "unavailable", immersionStatus: "unavailable" });
    }
  })();
  try {
    await graphBuildPromise;
  } finally {
    if (!mediaSourceConnected) graphBuildPromise = null;
  }
}
function rmsDbFromAnalyser(analyser: AnalyserNode) {
  const values = new Float32Array(analyser.fftSize);
  analyser.getFloatTimeDomainData(values);
  let sum = 0;
  for (let index = 0; index < values.length; index += 1) sum += values[index] * values[index];
  return gainToDb(Math.sqrt(sum / Math.max(1, values.length)));
}
function startLevelMeter() {
  if (typeof window === "undefined" || levelMeterTimer) return;
  levelMeterTimer = window.setInterval(() => {
    if (!state.playing || !referenceLevelAnalyser || !processedLevelAnalyser) return;
    if (state.dspEngineMode === "studio_wasm") {
      const runtime = getMvpStudioRuntimeInfo();
      if (runtime.faulted) {
        if (state.dspStatus !== "recovering") emit({ dspStatus: "recovering" });
        const now = Date.now();
        if (!studioRecoveryInFlight && now - lastStudioRecoveryAt > 4000) {
          studioRecoveryInFlight = true;
          lastStudioRecoveryAt = now;
          void rebuildMusicAudioEngine().catch(() => emit({ dspStatus: "unavailable" })).finally(() => { studioRecoveryInFlight = false; });
        }
        return;
      }
      const pureReference = state.outputProfile === "reference";
      const abBypass = !pureReference && state.dspBypass;
      const stateVerified = runtime.ready && runtime.requestedRevision <= runtime.appliedRevision;
      const verifiedStatus: MusicDspStatus = pureReference || abBypass
        ? "bypassed"
        : stateVerified
          ? "active"
          : "recovering";
      setDspTelemetry(verifiedStatus, state.effectivePreampDb, state.autoHeadroomDb);
      const telemetry = getMvpStudioTelemetry();
      const loudnessActive = state.normalizationEnabled && state.outputProfile !== "reference" && !state.dspBypass;
      const gainDb = loudnessActive && Number.isFinite(telemetry.loudnessGainDb)
        ? Math.round(telemetry.loudnessGainDb * 10) / 10
        : 0;
      const programLufs = loudnessActive && Number.isFinite(telemetry.loudnessProgramLufs) && telemetry.loudnessProgramLufs > -69.5
        ? Math.round(telemetry.loudnessProgramLufs * 10) / 10
        : -70;
      const dynamicEqActive = state.dynamicEqEnabled && state.outputProfile !== "reference" && !state.dspBypass;
      const dynamicEqGainReductionDb = dynamicEqActive && Number.isFinite(telemetry.dynamicEqGainReductionDb)
        ? Math.round(telemetry.dynamicEqGainReductionDb * 10) / 10
        : 0;
      const dynamicEqBandReductionDb = (dynamicEqActive
        ? [0, 1, 2, 3].map((index) => Math.round((Number(telemetry.dynamicEqBandReductionDb?.[index]) || 0) * 10) / 10)
        : [0, 0, 0, 0]) as [number, number, number, number];
      const dynamicEqChanged = dynamicEqGainReductionDb !== state.dynamicEqGainReductionDb
        || dynamicEqBandReductionDb.some((value, index) => value !== state.dynamicEqBandReductionDb[index]);
      const outputCorrectionActive = state.outputProfile !== "reference" && !state.dspBypass;
      const outputCorrectionReductionDb = outputCorrectionActive && Number.isFinite(telemetry.outputCorrectionReductionDb)
        ? Math.round(telemetry.outputCorrectionReductionDb * 10) / 10
        : 0;
      const outputCorrectionChanged = outputCorrectionReductionDb !== state.outputCorrectionReductionDb;
      const stereoIntegrityActive = state.outputProfile !== "reference" && !state.dspBypass;
      const stereoCorrelation = stereoIntegrityActive && Number.isFinite(telemetry.stereoCorrelation)
        ? Math.round(Math.max(-1, Math.min(1, telemetry.stereoCorrelation)) * 100) / 100
        : 1;
      const stereoWidthPercent = stereoIntegrityActive && Number.isFinite(telemetry.stereoWidthPercent)
        ? Math.round(Math.max(0, Math.min(140, telemetry.stereoWidthPercent)))
        : 100;
      const stereoGuardReductionDb = stereoIntegrityActive && Number.isFinite(telemetry.stereoGuardReductionDb)
        ? Math.round(Math.max(0, telemetry.stereoGuardReductionDb) * 10) / 10
        : 0;
      const stereoIntegrityChanged = stereoCorrelation !== state.stereoCorrelation
        || stereoWidthPercent !== state.stereoWidthPercent
        || stereoGuardReductionDb !== state.stereoGuardReductionDb;
      const truePeakDbtp = Number.isFinite(telemetry.truePeakDbtp)
        ? Math.round(telemetry.truePeakDbtp * 10) / 10
        : -120;
      const limiterGainReductionDb = state.limiterEnabled && Number.isFinite(telemetry.gainReductionDb)
        ? Math.round(Math.max(0, telemetry.gainReductionDb) * 10) / 10
        : 0;
      const transientActive = state.outputProfile !== "reference" && state.eqEnabled && !state.dspBypass;
      const transientBoostDb = transientActive && Number.isFinite(telemetry.transientBoostDb)
        ? Math.round(Math.max(0, telemetry.transientBoostDb) * 10) / 10
        : 0;
      const multibandActive = state.multibandEnabled && state.outputProfile !== "reference" && !state.dspBypass;
      const multibandGainReductionDb = multibandActive && Number.isFinite(telemetry.multibandGainReductionDb)
        ? Math.round(Math.max(0, telemetry.multibandGainReductionDb) * 10) / 10
        : 0;
      const coreMeterChanged = truePeakDbtp !== state.truePeakDbtp
        || limiterGainReductionDb !== state.limiterGainReductionDb
        || transientBoostDb !== state.transientBoostDb
        || multibandGainReductionDb !== state.multibandGainReductionDb;
      if (gainDb !== state.loudnessGainDb || programLufs !== state.loudnessMomentaryLufs || dynamicEqChanged || outputCorrectionChanged || stereoIntegrityChanged || coreMeterChanged) {
        emit({
          loudnessGainDb: gainDb,
          loudnessMomentaryLufs: programLufs,
          dynamicEqGainReductionDb,
          dynamicEqBandReductionDb,
          outputCorrectionReductionDb,
          stereoCorrelation,
          stereoWidthPercent,
          stereoGuardReductionDb,
          truePeakDbtp,
          limiterGainReductionDb,
          transientBoostDb,
          multibandGainReductionDb,
        });
      }
    }
    const referenceDb = rmsDbFromAnalyser(referenceLevelAnalyser);
    if (Number.isFinite(referenceDb) && referenceDb > -80) {
      lastReferenceRmsDb = Number.isFinite(lastReferenceRmsDb) ? lastReferenceRmsDb * 0.86 + referenceDb * 0.14 : referenceDb;
    }
    if (state.outputProfile !== "reference" && !state.dspBypass) {
      const processedDb = rmsDbFromAnalyser(processedLevelAnalyser);
      if (Number.isFinite(processedDb) && processedDb > -80) {
        lastProcessedRmsDb = Number.isFinite(lastProcessedRmsDb) ? lastProcessedRmsDb * 0.86 + processedDb * 0.14 : processedDb;
      }
    }
  }, 200);
}

async function unlockMusicAudio() {
  await connectMusicGraph();
  const context = getAudioContext();
  if (context?.state === "suspended") await context.resume();
  if (mediaSourceConnected) {
    applyProcessingSettings();
    startLevelMeter();
  }
}

function configureMediaSession() {
  if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
  const current = state.currentTrack;
  try {
    navigator.mediaSession.metadata = current
      ? new MediaMetadata({
          title: current.title,
          artist: current.artist || "MVP Trainer Music",
          album: current.album || state.activePlaylistName || "MVP Trainer",
        })
      : null;
  } catch {
    /* optional */
  }
  if (current?.artwork_path || current?.external_artwork_url) {
    void getMusicArtworkSignedUrl(current)
      .then((url: string | null) => {
        if (!url || state.currentTrack?.id !== current.id) return;
        try {
          navigator.mediaSession.metadata = new MediaMetadata({
            title: current.title,
            artist: current.artist || "MVP Trainer Music",
            album: current.album || state.activePlaylistName || "MVP Trainer",
            artwork: [{ src: url, sizes: "512x512" }],
          });
        } catch {
          /* optional */
        }
      })
      .catch(() => undefined);
  }
  const actions: Array<[MediaSessionAction, MediaSessionActionHandler | null]> = [
    ["play", () => void playMusic()],
    ["pause", pauseMusic],
    ["previoustrack", () => void previousMusicTrack()],
    ["nexttrack", () => void nextMusicTrack()],
    ["stop", stopMusic],
    ["seekto", (details) => {
      if (typeof details.seekTime === "number") seekMusic(details.seekTime);
    }],
  ];
  actions.forEach(([action, handler]) => {
    try {
      navigator.mediaSession.setActionHandler(action, handler);
    } catch {
      /* partial support */
    }
  });
}

function savePlaybackPosition() {
  if (!audioElement || !state.currentTrack) return;
  const now = Date.now();
  if (now - timeSaveTimer < 1500) return;
  timeSaveTimer = now;
  savePlayerSetting(STORAGE_KEYS.currentTime, String(audioElement.currentTime || 0));
}

function ensureAudioElement() {
  if (audioElement) return audioElement;
  const audio = new Audio();
  audio.preload = "metadata";
  audio.crossOrigin = "anonymous";
  audio.volume = 1;
  audio.addEventListener("play", () => {
    if (audio !== audioElement) return;
    playbackIntent = true;
    emit({ playing: true, error: null });
    configureMediaSession();
    const trackId = audio.dataset.trackId;
    const token = trackId ? `${trackId}:${audio.currentSrc || audio.src}` : "";
    if (trackId && token !== recordedPlayToken) {
      recordedPlayToken = token;
      void recordMusicTrackPlayed(trackId).catch(() => undefined);
    }
  });
  audio.addEventListener("pause", () => { if (audio === audioElement) emit({ playing: false }); });
  audio.addEventListener("loadedmetadata", () => {
    if (audio !== audioElement) return;
    const duration = Number(audio.duration);
    emit({ duration: Number.isFinite(duration) ? duration : 0 });
  });
  audio.addEventListener("durationchange", () => {
    if (audio !== audioElement) return;
    const duration = Number(audio.duration);
    emit({ duration: Number.isFinite(duration) ? duration : 0 });
  });
  audio.addEventListener("timeupdate", () => {
    if (audio !== audioElement) return;
    emit({ currentTime: audio.currentTime || 0 });
    savePlaybackPosition();
    const duration = Number(audio.duration);
    const remaining = duration - Number(audio.currentTime || 0);
    if (Number.isFinite(remaining) && remaining <= 12 && remaining > 0) {
      void preloadNextTransitionTrack();
    }
  });
  audio.addEventListener("ended", () => {
    if (audio !== audioElement) return;
    const finishedId = state.currentTrack?.id;
    recordedPlayToken = "";
    emit({ playing: false, currentTime: 0 });
    if (finishedId) void recordMusicTrackCompleted(finishedId).catch(() => undefined);
    void handleTrackEnded();
  });
  audio.addEventListener("error", () => {
    if (!state.loading) emit({ playing: false, error: "COULDN'T PLAY THIS TRACK • RETRY" });
  });
  audioElement = audio;
  return audio;
}

async function resolveTrackUrl(track: MusicTrack, force = false) {
  const cached = signedUrlCache.get(track.id);
  if (!force && cached && Date.now() - cached.cachedAt < SIGNED_URL_TTL_MS) return cached.url;
  if (force) {
    signedUrlCache.delete(track.id);
    clearMusicUrlCache(track.id);
  }
  const url = await getMusicTrackSignedUrl(track);
  signedUrlCache.set(track.id, { url, cachedAt: Date.now() });
  return url;
}

async function assignTrackSource(track: MusicTrack, startAt: number, force: boolean) {
  const audio = ensureAudioElement();
  const url = !force && transitionPreloadTrackId === track.id && transitionPreloadUrl
    ? transitionPreloadUrl
    : await resolveTrackUrl(track, force);
  if (loadingTrackId !== track.id) return;
  if (audio.dataset.trackId !== track.id || audio.src !== url) {
    audio.pause();
    recordedPlayToken = "";
    audio.src = url;
    audio.dataset.trackId = track.id;
    loudnessNormalizerNode?.port.postMessage({ type: "reset" });
    resetMvpStudioLoudness(studioProcessorNode);
    emit({ loudnessGainDb: 0, loudnessMomentaryLufs: -70 });
    audio.load();
  }
  const seekWhenReady = () => {
    const target = Math.max(0, Number(startAt) || 0);
    try {
      audio.currentTime =
        target > 0 && Number.isFinite(audio.duration)
          ? Math.min(target, Math.max(0, audio.duration - 0.25))
          : target;
    } catch {
      /* metadata may still settle */
    }
  };
  if (audio.readyState >= 1) seekWhenReady();
  else audio.addEventListener("loadedmetadata", seekWhenReady, { once: true });
}

async function loadTrack(track: MusicTrack, startAt = 0) {
  const shouldResetLoudness = state.currentTrack?.id !== track.id || startAt < 0.5;
  if (shouldResetLoudness) {
    loudnessNormalizerNode?.port.postMessage({ type: "reset" });
    resetMvpStudioLoudness(studioProcessorNode);
    emit({ loudnessGainDb: 0, loudnessMomentaryLufs: -70 });
  }
  loadingTrackId = track.id;
  emit({ loading: true, error: null, currentTrack: track });
  savePlayerSetting(STORAGE_KEYS.currentTrackId, track.id);
  configureMediaSession();
  try {
    try {
      await assignTrackSource(track, startAt, false);
    } catch {
      await assignTrackSource(track, startAt, true);
    }
    if (loadingTrackId !== track.id) return;
    emit({ loading: false, currentTime: startAt, error: null });
    void preloadNextTransitionTrack();
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not load this song.";
    emit({ loading: false, playing: false, error: `COULDN'T PLAY THIS TRACK • ${message}` });
    throw error;
  } finally {
    if (loadingTrackId === track.id) loadingTrackId = null;
  }
}

function getCurrentIndex() {
  return state.currentTrack
    ? state.tracks.findIndex((track) => track.id === state.currentTrack?.id)
    : -1;
}
function nextSequentialIndex(direction: 1 | -1) {
  const count = state.tracks.length;
  if (!count) return -1;
  const current = getCurrentIndex();
  if (current < 0) return direction === 1 ? 0 : count - 1;
  const next = current + direction;
  if (next >= 0 && next < count) return next;
  return state.repeat === "all" ? (direction === 1 ? 0 : count - 1) : -1;
}
function nextShuffleIndex() {
  const count = state.tracks.length;
  if (count <= 1) return count ? 0 : -1;
  const current = getCurrentIndex();
  let next = current;
  while (next === current) next = Math.floor(Math.random() * count);
  return next;
}
function nextTransitionCandidate() {
  if (!state.tracks.length || state.repeat === "one") return null;
  if (state.currentTrack && isAdaptiveRadioName(state.activePlaylistName)) {
    return chooseAdaptiveNextTrack(state.currentTrack, state.libraryTracks) ?? null;
  }
  // A shuffled next choice is intentionally selected at transition time, not preloaded early.
  if (state.shuffle) return null;
  const index = nextSequentialIndex(1);
  return index >= 0 ? state.tracks[index] ?? null : null;
}

function clearTransitionPreload() {
  if (transitionPreloadAudio) {
    try {
      transitionPreloadAudio.pause();
      transitionPreloadAudio.removeAttribute("src");
      transitionPreloadAudio.load();
    } catch { /* preload cleanup */ }
  }
  transitionPreloadAudio = null;
  transitionPreloadTrackId = null;
  transitionPreloadUrl = null;
}

async function preloadNextTransitionTrack() {
  if (state.transitionMode === "off") return;
  const next = nextTransitionCandidate();
  if (!next || next.id === transitionPreloadTrackId) return;
  try {
    const url = await resolveTrackUrl(next, false);
    if (next.id !== nextTransitionCandidate()?.id) return;
    clearTransitionPreload();
    const preload = new Audio();
    preload.preload = "auto";
    preload.crossOrigin = "anonymous";
    preload.volume = 0;
    preload.src = url;
    preload.load();
    transitionPreloadAudio = preload;
    transitionPreloadTrackId = next.id;
    transitionPreloadUrl = url;
  } catch {
    clearTransitionPreload();
  }
}

function transitionTimings() {
  if (state.transitionMode === "off" || state.transitionMode === "gapless") return { down: 0, up: 0 };
  if (state.transitionMode === "smooth") return { down: 180, up: 420 };
  return { down: 90, up: 260 };
}

async function handleTrackEnded() {
  if (state.repeat === "one" && state.currentTrack) {
    await playMusicTrack(state.currentTrack.id, 0);
    return;
  }
  const { up } = transitionTimings();
  const originalGain = Math.max(0.0001, musicGain?.gain.value || 1);
  if (up > 0 && musicGain && audioContext) {
    musicGain.gain.cancelScheduledValues(audioContext.currentTime);
    musicGain.gain.setValueAtTime(0.0001, audioContext.currentTime);
  }
  await nextMusicTrack(true);
  clearTransitionPreload();
  if (up > 0 && musicGain && audioContext) await fadeOutputTo(originalGain, up);
  void preloadNextTransitionTrack();
}

async function resolveSavedQueue(libraryTracks: MusicTrack[]) {
  const savedPlaylistId = readStored(STORAGE_KEYS.activePlaylistId);
  if (!savedPlaylistId) {
    const savedQueueName = readStored(STORAGE_KEYS.activePlaylistName);
    const savedQueueIdsRaw = readStored(STORAGE_KEYS.activeQueueTrackIds);
    if (savedQueueName && savedQueueIdsRaw) {
      try {
        const ids = JSON.parse(savedQueueIdsRaw);
        if (Array.isArray(ids) && ids.length) {
          const byId = new Map(libraryTracks.map((track) => [track.id, track]));
          const tracks = ids.map((id) => byId.get(String(id))).filter((track): track is MusicTrack => Boolean(track));
          if (tracks.length) return { tracks, playlistId: null as string | null, playlistName: savedQueueName };
        }
      } catch { /* fall through */ }
    }
    removePlayerSetting(STORAGE_KEYS.activePlaylistName);
    removePlayerSetting(STORAGE_KEYS.activeQueueTrackIds);
    return { tracks: libraryTracks, playlistId: null as string | null, playlistName: null as string | null };
  }
  try {
    const [playlist, links] = await Promise.all([getMusicPlaylist(savedPlaylistId), listMusicPlaylistTrackLinks(savedPlaylistId)]);
    if (!playlist) throw new Error("Playlist no longer exists.");
    const byId = new Map(libraryTracks.map((track) => [track.id, track]));
    const tracks = links.map((link) => byId.get(link.track_id)).filter((track): track is MusicTrack => Boolean(track));
    if (!tracks.length) throw new Error("Playlist is empty.");
    return { tracks, playlistId: playlist.id, playlistName: playlist.name };
  } catch {
    removePlayerSetting(STORAGE_KEYS.activePlaylistId);
    removePlayerSetting(STORAGE_KEYS.activePlaylistName);
    removePlayerSetting(STORAGE_KEYS.activeQueueTrackIds);
    return { tracks: libraryTracks, playlistId: null as string | null, playlistName: null as string | null };
  }
}
export async function loadMusicLibrary(force = false) {
  if (state.loading) return state.libraryTracks;
  if (state.libraryLoaded && !force) return state.libraryTracks;
  emit({ loading: true, error: null });
  try {
    const libraryTracks = await listMusicTracks();
    const queue = await resolveSavedQueue(libraryTracks);
    const savedTrackId = readStored(STORAGE_KEYS.currentTrackId);
    const currentTrack =
      queue.tracks.find((track) => track.id === state.currentTrack?.id) ??
      queue.tracks.find((track) => track.id === savedTrackId) ??
      queue.tracks[0] ??
      null;
    emit({
      libraryTracks,
      tracks: queue.tracks,
      activePlaylistId: queue.playlistId,
      activePlaylistName: queue.playlistName,
      currentTrack,
      loading: false,
      libraryLoaded: true,
      error: null,
    });
    configureMediaSession();
    return libraryTracks;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not load your music library.";
    emit({ loading: false, libraryLoaded: true, error: message });
    return [];
  }
}

export function replaceMusicLibrary(libraryTracks: MusicTrack[]) {
  const byId = new Map(libraryTracks.map((track) => [track.id, track]));
  const hasScopedQueue = Boolean(state.activePlaylistId || state.activePlaylistName);
  const tracks = hasScopedQueue
    ? state.tracks.map((track) => byId.get(track.id) ?? track)
    : libraryTracks;
  const currentTrack = state.currentTrack
    ? tracks.find((track) => track.id === state.currentTrack?.id) ?? byId.get(state.currentTrack.id) ?? state.currentTrack
    : tracks[0] ?? null;
  emit({ libraryTracks, tracks, currentTrack, libraryLoaded: true });
  configureMediaSession();
}
export function activateAllMusicTracks() {
  removePlayerSetting(STORAGE_KEYS.activePlaylistId);
  removePlayerSetting(STORAGE_KEYS.activePlaylistName);
  removePlayerSetting(STORAGE_KEYS.activeQueueTrackIds);
  const currentTrack =
    state.libraryTracks.find((track) => track.id === state.currentTrack?.id) ??
    state.libraryTracks[0] ??
    null;
  emit({
    tracks: [...state.libraryTracks],
    currentTrack,
    activePlaylistId: null,
    activePlaylistName: null,
    error: null,
  });
  configureMediaSession();
}

export function activateMusicAdHocQueue(name: string, tracks: MusicTrack[]) {
  removePlayerSetting(STORAGE_KEYS.activePlaylistId);
  savePlayerSetting(STORAGE_KEYS.activePlaylistName, name);
  savePlayerSetting(STORAGE_KEYS.activeQueueTrackIds, JSON.stringify(tracks.map((track) => track.id)));
  const currentTrack = tracks.find((track) => track.id === state.currentTrack?.id) ?? tracks[0] ?? null;
  emit({ tracks: [...tracks], currentTrack, activePlaylistId: null, activePlaylistName: name, error: tracks.length ? null : "This collection has no songs." });
  configureMediaSession();
}
export async function playMusicAdHocQueue(name: string, tracks: MusicTrack[], startTrackId?: string) {
  activateMusicAdHocQueue(name, tracks);
  const start = tracks.find((track) => track.id === startTrackId) ?? tracks[0];
  if (start) await playMusicTrack(start.id, 0);
}

export function activateMusicPlaylistQueue(
  playlist: Pick<MusicPlaylist, "id" | "name">,
  tracks: MusicTrack[],
) {
  savePlayerSetting(STORAGE_KEYS.activePlaylistId, playlist.id);
  savePlayerSetting(STORAGE_KEYS.activePlaylistName, playlist.name);
  removePlayerSetting(STORAGE_KEYS.activeQueueTrackIds);
  const currentTrack = tracks.find((track) => track.id === state.currentTrack?.id) ?? tracks[0] ?? null;
  emit({ tracks: [...tracks], currentTrack, activePlaylistId: playlist.id, activePlaylistName: playlist.name, error: tracks.length ? null : "This playlist has no songs." });
  configureMediaSession();
}
export async function playMusicPlaylist(
  playlist: Pick<MusicPlaylist, "id" | "name">,
  tracks: MusicTrack[],
  startTrackId?: string,
) {
  activateMusicPlaylistQueue(playlist, tracks);
  const start = tracks.find((track) => track.id === startTrackId) ?? tracks[0];
  if (!start) throw new Error("Add songs to this playlist before playing it.");
  await playMusicTrack(start.id, 0);
}

async function performPlayMusicTrack(trackId: string, startAt = 0) {
  playbackIntent = true;
  if (!state.libraryLoaded) await loadMusicLibrary();
  const track =
    state.tracks.find((item) => item.id === trackId) ??
    state.libraryTracks.find((item) => item.id === trackId);
  if (!track) throw new Error("Song not found in your music library.");
  if (!state.tracks.some((item) => item.id === trackId)) activateAllMusicTracks();
  await unlockMusicAudio();
  await loadTrack(track, startAt);
  await ensureAudioElement().play();
}

export function playMusicTrack(trackId: string, startAt = 0) {
  const operation = transportQueue
    .catch(() => undefined)
    .then(() => performPlayMusicTrack(trackId, startAt));
  transportQueue = operation.catch(() => undefined);
  return operation;
}

export async function playMusic() {
  playbackIntent = true;
  await unlockMusicAudio();
  if (!state.libraryLoaded) await loadMusicLibrary();
  const audio = ensureAudioElement();
  const track = state.currentTrack ?? state.tracks[0] ?? null;
  if (!track) {
    emit({ error: "Upload music before pressing Play." });
    return;
  }
  if (audio.dataset.trackId !== track.id || !audio.src) {
    const saved = Number(readStored(STORAGE_KEYS.currentTime) || 0);
    await loadTrack(track, Number.isFinite(saved) ? saved : 0);
  }
  await audio.play();
}

/* MVP_TRAINER_V4_5_2_TRUE_PAUSE_CONTINUITY_R4: PLAYBACK QUERY */
export function isMusicPlaying() {
  const audio = audioElement;
  return Boolean(audio && !audio.paused && !audio.ended && Boolean(audio.src));
}

export function pauseMusic() {
  playbackIntent = false;
  ensureAudioElement().pause();
}

export function stopMusic() {
  playbackIntent = false;
  const audio = ensureAudioElement();
  audio.pause();
  try {
    audio.currentTime = 0;
  } catch {
    /* mobile */
  }
  savePlayerSetting(STORAGE_KEYS.currentTime, "0");
  emit({ playing: false, currentTime: 0 });
}

export function seekMusic(seconds: number) {
  const audio = ensureAudioElement();
  const duration = Number.isFinite(audio.duration) ? audio.duration : state.duration;
  const next = Math.max(0, Math.min(Number(seconds) || 0, Math.max(0, duration || 0)));
  try {
    audio.currentTime = next;
    emit({ currentTime: next });
    savePlayerSetting(STORAGE_KEYS.currentTime, String(next));
  } catch {
    /* not ready */
  }
}

function shouldRecordSkip() {
  const audio = ensureAudioElement();
  const duration = Number.isFinite(audio.duration) ? audio.duration : state.duration;
  return Boolean(state.currentTrack && audio.currentTime < Math.max(30, (duration || 0) * 0.35));
}

async function playTrackWithIntelligentTransition(trackId: string, fromEnded: boolean) {
  const { down, up } = transitionTimings();
  if (fromEnded || state.transitionMode === "off" || state.transitionMode === "gapless" || !musicGain || !audioContext) {
    await playMusicTrack(trackId, 0);
    return;
  }
  const originalGain = Math.max(0.0001, musicGain.gain.value || 1);
  if (down > 0) await fadeOutputTo(Math.min(originalGain, 0.0001), down);
  await playMusicTrack(trackId, 0);
  if (up > 0) await fadeOutputTo(originalGain, up);
}

/* MVP_TRAINER_V5_R6_MUSIC_INTELLIGENCE_SUITE: ADAPTIVE NEXT */
export async function nextMusicTrack(fromEnded = false) {
  if (!state.libraryLoaded) await loadMusicLibrary();

  if (!fromEnded && shouldRecordSkip() && state.currentTrack) {
    void recordMusicTrackSkipped(state.currentTrack.id).catch(() => undefined);
  }

  if (
    state.currentTrack &&
    isAdaptiveRadioName(state.activePlaylistName)
  ) {
    const adaptive = chooseAdaptiveNextTrack(
      state.currentTrack,
      state.libraryTracks,
    );

    if (adaptive) {
      // Adaptive Radio and normal queues share the same transition engine.
      // Legacy AutoMix still enables the feature, but no artificial sound is inserted.
      if (isAutoMixEnabled() || state.transitionMode !== "off") await playTrackWithIntelligentTransition(adaptive.id, fromEnded);
      else await playMusicTrack(adaptive.id, 0);
      return;
    }
  }

  const index = state.shuffle
    ? nextShuffleIndex()
    : nextSequentialIndex(1);

  if (index < 0) {
    if (fromEnded) stopMusic();
    return;
  }

  const track = state.tracks[index];
  if (track) await playTrackWithIntelligentTransition(track.id, fromEnded);
}

export async function previousMusicTrack() {
  if (!state.libraryLoaded) await loadMusicLibrary();
  const audio = ensureAudioElement();
  if (audio.currentTime > 5 && state.currentTrack) {
    seekMusic(0);
    return;
  }
  const index = nextSequentialIndex(-1);
  if (index < 0) return;
  const track = state.tracks[index];
  if (track) await playMusicTrack(track.id, 0);
}

export function toggleMusicShuffle() {
  const shuffle = !state.shuffle;
  savePlayerSetting(STORAGE_KEYS.shuffle, String(shuffle));
  emit({ shuffle });
}

export function cycleMusicRepeat() {
  const repeat: MusicRepeatMode =
    state.repeat === "off" ? "all" : state.repeat === "all" ? "one" : "off";
  savePlayerSetting(STORAGE_KEYS.repeat, repeat);
  emit({ repeat });
}

export function addMusicToQueue(trackId: string) {
  const track = state.libraryTracks.find((item) => item.id === trackId);
  if (!track || state.tracks.some((item) => item.id === trackId)) return;
  emit({ tracks: [...state.tracks, track] });
}

export function playMusicNext(trackId: string) {
  const track = state.libraryTracks.find((item) => item.id === trackId);
  if (!track) return;
  const without = state.tracks.filter((item) => item.id !== trackId);
  const currentIndex = state.currentTrack
    ? without.findIndex((item) => item.id === state.currentTrack?.id)
    : -1;
  const insertAt = Math.max(0, currentIndex + 1);
  without.splice(insertAt, 0, track);
  emit({ tracks: without });
}

/* MVP_TRAINER_V5_R6_MUSIC_INTELLIGENCE_SUITE: LIKE RADIO + LIKED SONGS */
export async function setPlayerMusicPreference(
  trackId: string,
  preference: "neutral" | "like" | "play_less",
) {
  const wasCurrent = state.currentTrack?.id === trackId;
  const updated = await setMusicTrackPreference(trackId, preference);
  const patchTrack = (track: MusicTrack) =>
    track.id === trackId ? updated : track;

  const nextLibrary = state.libraryTracks.map(patchTrack);
  const nextQueue = state.tracks.map(patchTrack);

  emit({
    libraryTracks: nextLibrary,
    tracks: nextQueue,
    currentTrack: wasCurrent ? updated : state.currentTrack,
  });

  void syncLikedSongsPlaylist(nextLibrary).catch((error) => {
    console.warn("Could not synchronize Liked Songs.", error);
  });

  if (preference === "like" && wasCurrent) {
    const radio = startRadioSession(
      updated,
      nextLibrary,
      "more_like_this",
    );

    activateMusicAdHocQueue(
      `Like Radio • ${updated.title}`,
      radio,
    );
  }

  return updated;
}

export function startMvpNeuralRadio(
  seedTrackId: string,
  mode: MusicRadioMode = "more_like_this",
) {
  const seed = state.libraryTracks.find(
    (track) => track.id === seedTrackId,
  );

  if (!seed) {
    throw new Error("Song not found in your music library.");
  }

  const queue = startRadioSession(
    seed,
    state.libraryTracks,
    mode,
  );

  activateMusicAdHocQueue(
    adaptiveRadioQueueName(seed, mode),
    queue,
  );

  return queue;
}

export function getMusicPlayerSnapshot() {
  return state;
}

export function setMusicVolume(value: number) {
  const next = Math.max(0, Math.min(1, Number(value) || 0));
  savePlayerSetting(STORAGE_KEYS.volume, String(next));
  emit({ volume: next });
  if (audioContext && mediaSourceConnected && masterVolumeGain) {
    setAudioParam(masterVolumeGain.gain, volumeToGain(next), audioContext.currentTime, 0.01);
  } else if (audioElement) {
    audioElement.volume = next;
  }
}

export function setMusicEqEnabled(enabled: boolean) {
  savePlayerSetting(STORAGE_KEYS.eqEnabled, String(enabled));
  emit({ eqEnabled: enabled });
  applyProcessingSettings();
  scheduleProcessingSettle();
}

export function applyMusicEqPreset(presetName: MusicEqPreset) {
  if (isCustomPresetSlot(presetName)) {
    const definition = readCustomPreset(presetName);
    savePlayerSetting(STORAGE_KEYS.eqPreset, presetName);
    if (definition) {
      savePlayerSetting(STORAGE_KEYS.eqGains, JSON.stringify(definition.gains));
      savePlayerSetting(STORAGE_KEYS.preampDb, String(definition.preamp));
      emit({
        eqPreset: presetName,
        eqGains: [...definition.gains],
        preampDb: definition.preamp,
        dspVerificationMode: "off",
      });
    } else {
      emit({ eqPreset: presetName, dspVerificationMode: "off" });
    }
    applyProcessingSettings();
    scheduleProcessingSettle();
    return;
  }
  if (presetName === "custom") {
    savePlayerSetting(STORAGE_KEYS.eqPreset, presetName);
    emit({ eqPreset: presetName, dspVerificationMode: "off" });
    applyProcessingSettings();
    return;
  }
  if (!isBuiltInPreset(presetName)) return;
  const definition = MUSIC_EQ_PRESETS[presetName];
  const gains = [...definition.gains];
  savePlayerSetting(STORAGE_KEYS.eqPreset, presetName);
  savePlayerSetting(STORAGE_KEYS.eqGains, JSON.stringify(gains));
  savePlayerSetting(STORAGE_KEYS.preampDb, String(definition.preamp));
  emit({
    eqPreset: presetName,
    eqGains: gains,
    preampDb: definition.preamp,
    dspVerificationMode: "off",
  });
  applyProcessingSettings();
  scheduleProcessingSettle();
}

export function saveMusicEqCustomPreset(slot: MusicCustomPresetSlot) {
  const definition: EqDefinition = {
    label: slot === "custom_1" ? "Custom 1" : slot === "custom_2" ? "Custom 2" : "Custom 3",
    gains: [...state.eqGains],
    preamp: state.preampDb,
  };
  savePlayerSetting(customPresetStorageKey(slot), JSON.stringify(definition));
}

export function setMusicEqBand(index: number, gainDb: number) {
  if (index < 0 || index >= MUSIC_EQ_FREQUENCIES.length) return;
  const gains = [...state.eqGains];
  gains[index] = Math.max(-12, Math.min(12, Number(gainDb) || 0));
  savePlayerSetting(STORAGE_KEYS.eqGains, JSON.stringify(gains));
  savePlayerSetting(STORAGE_KEYS.eqPreset, "custom");
  emit({ eqGains: gains, eqPreset: "custom", dspVerificationMode: "off" });
  applyProcessingSettings();
}

export function setMusicPreamp(preampDb: number) {
  const next = Math.max(-12, Math.min(6, Number(preampDb) || 0));
  savePlayerSetting(STORAGE_KEYS.preampDb, String(next));
  savePlayerSetting(STORAGE_KEYS.eqPreset, "custom");
  emit({ preampDb: next, eqPreset: "custom", dspVerificationMode: "off" });
  applyProcessingSettings();
  scheduleProcessingSettle();
}

export function setMusicEqTopology(topology: MusicEqTopology) {
  const next: MusicEqTopology = topology === "linear_phase" ? "linear_phase" : "minimum_phase";
  const previous = state.eqTopology;
  savePlayerSetting(STORAGE_KEYS.eqTopology, next);
  emit({ eqTopology: next });
  // Studio can change topology in-place. Compatibility paths still rebuild so
  // they can retry the flagship Studio engine after a topology change.
  const engineSwitch = previous !== next && state.dspEngineMode !== "studio_wasm";
  if (engineSwitch) {
    void rebuildMusicAudioEngine();
    return;
  }
  applyProcessingSettings();
  scheduleProcessingSettle();
}

export function setMusicCrossfadeSeconds(seconds: number) {
  const next = Math.max(0, Math.min(8, Number(seconds) || 0));
  savePlayerSetting(STORAGE_KEYS.crossfadeSeconds, String(next));
  emit({ crossfadeSeconds: next });
}

export function setMusicTransitionMode(mode: MusicTransitionMode) {
  const next: MusicTransitionMode = mode === "gapless" || mode === "smooth" || mode === "off" ? mode : "auto";
  savePlayerSetting(STORAGE_KEYS.transitionMode, next);
  emit({ transitionMode: next });
  clearTransitionPreload();
  void preloadNextTransitionTrack();
}

export function setMusicNormalizationEnabled(enabled: boolean) {
  savePlayerSetting(STORAGE_KEYS.normalizationEnabled, String(enabled));
  emit({ normalizationEnabled: enabled });
  applyProcessingSettings();
  if (!enabled) {
    emit({ loudnessGainDb: 0, loudnessMomentaryLufs: -70 });
  } else {
    loudnessNormalizerNode?.port.postMessage({ type: "reset" });
    resetMvpStudioLoudness(studioProcessorNode);
  }
}

export function setMusicMultibandEnabled(enabled: boolean) {
  savePlayerSetting(STORAGE_KEYS.multibandEnabled, String(enabled));
  emit({ multibandEnabled: enabled });
  applyProcessingSettings();
}
export function setMusicDynamicEqEnabled(enabled: boolean) {
  savePlayerSetting(STORAGE_KEYS.dynamicEqEnabled, String(enabled));
  if (enabled) emit({ dynamicEqEnabled: true });
  else emit({ dynamicEqEnabled: false, dynamicEqGainReductionDb: 0, dynamicEqBandReductionDb: [0, 0, 0, 0] });
  applyProcessingSettings();
}

export function setMusicLimiterEnabled(enabled: boolean) {
  savePlayerSetting(STORAGE_KEYS.limiterEnabled, String(enabled));
  emit({ limiterEnabled: enabled });
  applyProcessingSettings();
}

export function setMusicDuckingStrength(value: MusicDuckingStrength) {
  savePlayerSetting(STORAGE_KEYS.duckingStrength, value);
  emit({ duckingStrength: value });
}

export function getNextMusicTrackPreview() {
  if (!state.tracks.length) return null;
  if (state.shuffle) return { track: null as MusicTrack | null, label: "Shuffle selection" };
  const index = nextSequentialIndex(1);
  return {
    track: index >= 0 ? state.tracks[index] ?? null : null,
    label: index >= 0 ? state.tracks[index]?.title ?? "Next track" : "End of queue",
  };
}

function applyHeadphoneModeValues(mode: MusicHeadphoneMode) {
  const values = MUSIC_HEADPHONE_MODES[mode];
  savePlayerSetting(STORAGE_KEYS.headphoneMode, mode);
  savePlayerSetting(STORAGE_KEYS.headphoneWidth, String(values.width));
  savePlayerSetting(STORAGE_KEYS.headphoneDepth, String(values.depth));
  savePlayerSetting(STORAGE_KEYS.headphoneCrossfeed, String(values.crossfeed));
  savePlayerSetting(STORAGE_KEYS.headphoneCenter, String(values.center));
  savePlayerSetting(STORAGE_KEYS.headphoneBassImpact, String(values.bass));
  emit({
    headphoneMode: mode,
    headphoneWidth: values.width,
    headphoneDepth: values.depth,
    headphoneCrossfeed: values.crossfeed,
    headphoneCenter: values.center,
    headphoneBassImpact: values.bass,
  });
  applyProcessingSettings();
}
export function setMusicHeadphoneMode(mode: MusicHeadphoneMode) {
  applyHeadphoneModeValues(mode);
}
function setHeadphoneValue(
  key: keyof Pick<
    MusicPlayerState,
    | "headphoneWidth"
    | "headphoneDepth"
    | "headphoneCrossfeed"
    | "headphoneCenter"
    | "headphoneBassImpact"
  >,
  storageKey: string,
  value: number,
) {
  const next = Math.max(0, Math.min(100, Number(value) || 0));
  savePlayerSetting(storageKey, String(next));
  emit({ [key]: next } as Pick<MusicPlayerState, typeof key>);
  applyProcessingSettings();
}
export function setMusicHeadphoneWidth(value: number) {
  setHeadphoneValue("headphoneWidth", STORAGE_KEYS.headphoneWidth, value);
}
export function setMusicHeadphoneDepth(value: number) {
  setHeadphoneValue("headphoneDepth", STORAGE_KEYS.headphoneDepth, value);
}
export function setMusicHeadphoneCrossfeed(value: number) {
  setHeadphoneValue("headphoneCrossfeed", STORAGE_KEYS.headphoneCrossfeed, value);
}
export function setMusicHeadphoneCenter(value: number) {
  setHeadphoneValue("headphoneCenter", STORAGE_KEYS.headphoneCenter, value);
}
export function setMusicHeadphoneBassImpact(value: number) {
  setHeadphoneValue("headphoneBassImpact", STORAGE_KEYS.headphoneBassImpact, value);
}

export function setMusicDspVerificationMode(mode: MusicDspVerificationMode) {
  const next: MusicDspVerificationMode = mode === "eq" || mode === "spatial" ? mode : "off";
  emit({ dspVerificationMode: next });
  applyProcessingSettings();
  scheduleProcessingSettle();
}

export function setMusicOutputProfile(profile: MusicOutputProfile) {
  if (!Object.prototype.hasOwnProperty.call(MUSIC_OUTPUT_PROFILES, profile)) return;
  savePlayerSetting(STORAGE_KEYS.outputProfile, profile);
  savePlayerSetting(STORAGE_KEYS.dspBypass, "false");
  emit({
    outputProfile: profile,
    dspBypass: false,
    dspVerificationMode: "off",
  });
  applyProcessingSettings();
}

export function setMusicDspBypass(bypassed: boolean) {
  savePlayerSetting(STORAGE_KEYS.dspBypass, String(bypassed));
  emit({ dspBypass: bypassed, dspVerificationMode: "off" });
  applyProcessingSettings();
}

export async function recoverMusicDsp() {
  try {
    await unlockMusicAudio();
    applyProcessingSettings();
  } catch {
    emit({ dspStatus: "unavailable" });
  }
}

export async function rebuildMusicAudioEngine() {
  const track = state.currentTrack;
  const wasPlaying = state.playing || playbackIntent;
  const position = state.currentTime;
  if (audioElement) {
    try {
      audioElement.pause();
      audioElement.removeAttribute("src");
      audioElement.load();
    } catch {
      /* ignore */
    }
  }
  releaseGraph();
  if (audioContext && audioContext.state !== "closed") {
    try {
      await audioContext.close();
    } catch {
      /* ignore */
    }
  }
  audioContext = null;
  audioElement = null;
  if (!track) return;
  await unlockMusicAudio();
  await loadTrack(track, position);
  if (wasPlaying) await ensureAudioElement().play();
}

export function getMusicVisualizerLevels(barCount = 10) {
  const count = Math.max(4, Math.min(64, Math.floor(barCount)));
  if (visualizerEnvelope.length !== count) visualizerEnvelope = new Float32Array(count);
  if (!analyserNode || !audioContext) {
    for (let index = 0; index < count; index += 1) {
      visualizerEnvelope[index] = Math.max(0, visualizerEnvelope[index] * 0.82 - index * 0.00015);
    }
    return Array.from(visualizerEnvelope);
  }
  if (!analyserBuffer || analyserBuffer.length !== analyserNode.frequencyBinCount) {
    const buffer = new ArrayBuffer(analyserNode.frequencyBinCount);
    analyserBuffer = new Uint8Array(buffer);
  }
  analyserNode.getByteFrequencyData(analyserBuffer);
  const data = analyserBuffer;
  const nyquist = audioContext.sampleRate / 2;
  const minHz = 35;
  const maxHz = Math.min(18000, nyquist * 0.92);
  const ratio = maxHz / minHz;
  for (let index = 0; index < count; index += 1) {
    const lowHz = minHz * Math.pow(ratio, index / count);
    const highHz = minHz * Math.pow(ratio, (index + 1) / count);
    const lowBin = Math.max(0, Math.floor((lowHz / nyquist) * data.length));
    const highBin = Math.max(lowBin + 1, Math.ceil((highHz / nyquist) * data.length));
    let total = 0;
    let peak = 0;
    let samples = 0;
    for (let bin = lowBin; bin < Math.min(highBin, data.length); bin += 1) {
      const value = data[bin];
      total += value;
      peak = Math.max(peak, value);
      samples += 1;
    }
    const average = samples ? total / samples : 0;
    const raw = Math.min(1, (average * 0.72 + peak * 0.28) / 210);
    const shaped = Math.pow(raw, 0.78);
    const previous = visualizerEnvelope[index] || 0;
    visualizerEnvelope[index] = state.playing
      ? shaped > previous
        ? previous + (shaped - previous) * 0.72
        : previous + (shaped - previous) * 0.24
      : Math.max(0, previous * 0.84 - 0.006);
  }
  return Array.from(visualizerEnvelope);
}

export function getMusicRtaLevels() {
  return getMusicVisualizerLevels(10);
}
export function getMusicStudioTelemetry() {
  return getMvpStudioTelemetry();
}

function duckTargetForStrength(strength: MusicDuckingStrength) {
  return strength === "off" ? 1 : strength === "light" ? 0.5 : strength === "strong" ? 0.08 : 0.18;
}
function fadeOutputTo(target: number, milliseconds: number) {
  if (!musicGain || !audioContext) return Promise.resolve();
  const now = audioContext.currentTime;
  const seconds = Math.max(0.03, milliseconds / 1000);
  musicGain.gain.cancelScheduledValues(now);
  musicGain.gain.setValueAtTime(Math.max(0.0001, musicGain.gain.value), now);
  musicGain.gain.linearRampToValueAtTime(Math.max(0.0001, target), now + seconds);
  return new Promise<void>((resolve) => window.setTimeout(resolve, milliseconds + 20));
}

export async function playWithMusicDucked(playAlert: () => Promise<void>) {
  const audio = ensureAudioElement();
  const wasPlaying = !audio.paused && !audio.ended && Boolean(audio.src);
  if (!wasPlaying || state.duckingStrength === "off") {
    await playAlert();
    return;
  }
  await unlockMusicAudio();
  if (musicGain && audioContext) {
    const original = Math.max(0.0001, musicGain.gain.value || 1);
    try {
      await fadeOutputTo(duckTargetForStrength(state.duckingStrength), 180);
      await playAlert();
    } finally {
      await fadeOutputTo(original, 360);
    }
    return;
  }
  const original = audio.volume;
  try {
    audio.volume = Math.min(original, duckTargetForStrength(state.duckingStrength));
    await playAlert();
  } finally {
    audio.volume = original;
  }
}

export function formatMusicTime(value: number) {
  const total = Math.max(0, Math.floor(Number(value) || 0));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
function getSnapshot() {
  return state;
}
export function useMusicPlayer() {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}
